"""통신 규약 구현 — 직렬화 · 파싱 · 검증 (FR-5.1/5.2).

**정본은 이 파일이 아니라 docs/PROTOCOL.md 다.**
이 파일은 그 문서의 Python 구현이고, C++ 펌웨어(`command_parser`)는 같은 문서의
C++ 구현이다. 둘이 어긋나면 같은 골든 픽스처를 보는 CI 가 잡는다.

    tests/fixtures/protocol_samples.jsonl   ─┬─▶ Python  (tests/test_protocol.py)
    tests/fixtures/protocol_invalid.jsonl   ─┘   C++     (호스트 컴파일 · M1)

설계 결정 세 가지 — 나머지는 전부 여기서 따라 나온다.

1. **판정과 실행을 분리한다** (ENGINEERING_GUIDE 2.1).
   디코더는 로그를 남기지도, 소켓을 만지지도 않는다. `DecodeResult` 를 돌려줄
   뿐이고 WARN 을 남길지는 호출자가 정한다. 그래야 하드웨어 없이 pytest 로 닫힌다.

2. **시각은 주입받는다.** `time.time()` 을 직접 부르는 곳은 `system_clock_ms()`
   하나뿐이며, 인코더는 이것을 인자로 받는다. 테스트는 가짜 시계를 넣는다.

3. **seq 는 유효성과 무관하게 진행한다.** 내용 검증에서 폐기된 패킷의 seq 도
   «지나간 순번» 이라, 옛 패킷이 뒤늦게 받아들여지지 않는다.

여기 있는 숫자는 튜닝 파라미터가 아니라 **규약 상수**다 (HW_MechDog API 허용 범위 ·
ADR-1). 바꾸려면 파괴적 변경 절차를 따른다 (PROTOCOL.md 4절).
"""

import json
import math
import time
from collections.abc import Callable, Hashable
from dataclasses import dataclass
from enum import StrEnum
from typing import Any, TypeGuard

# ══════════════════════════════════════════════════════════════
#  1. 규약 상수 — PROTOCOL.md 2절 · 5절
# ══════════════════════════════════════════════════════════════

#: 제어 명령 11종. 여기 없는 타입은 폐기 + WARN 이며, 그 덕분에 타입 추가는
#: 항상 하위 호환이다 (PROTOCOL.md 4절). `STATE` 가 그 첫 사례다.
COMMAND_TYPES: frozenset[str] = frozenset(
    {
        "MOVE",
        "POSE",
        "GAIT",
        "STOP",
        "ACTION",
        "LED",
        "SOUND",
        "STATE",
        "ESTOP",
        "RESET_SAFE",
        "SERVICE",
    }
)

#: 모든 명령의 공통 필수 필드. `seq`·`ts` 는 **정수**, `type` 은 문자열이다.
COMMON_REQUIRED: tuple[str, ...] = ("seq", "ts", "type")
COMMON_REQUIRED_SET: frozenset[str] = frozenset(COMMON_REQUIRED)

#: 타입별 필수 필드.
REQUIRED_FIELDS: dict[str, frozenset[str]] = {
    "MOVE": frozenset({"step", "angle"}),
    "POSE": frozenset({"pitch", "roll", "height", "dur"}),
    "GAIT": frozenset({"lift_time", "ground_time", "height"}),
    "STOP": frozenset(),
    "ESTOP": frozenset(),
    "RESET_SAFE": frozenset(),
    "ACTION": frozenset({"id"}),
    "LED": frozenset({"color", "blink_hz"}),
    "SOUND": frozenset({"track"}),
    "STATE": frozenset({"state"}),
    "SERVICE": frozenset({"mode"}),
}

#: SERVICE 명령의 mode 값. 모르는 값은 폐기 + WARN — 상태와 같은 이유로
#: 모드 추가를 하위 호환으로 만든다.
SERVICE_MODES: frozenset[str] = frozenset({"enter", "exit"})

#: 문자열로 받는 필드. 나머지 필수 필드는 전부 수치다.
STRING_FIELDS: frozenset[str] = frozenset({"color", "state", "mode"})
INTEGER_FIELDS: frozenset[str] = frozenset({"dur", "lift_time", "ground_time", "id", "track"})
NONNEGATIVE_FIELDS: dict[str, tuple[str, ...]] = {
    "POSE": ("dur",),
    "GAIT": ("lift_time", "ground_time", "height"),
    "LED": ("blink_hz",),
    "SOUND": ("track",),
}

#: 클램핑 대상 — PROTOCOL.md 가 범위를 명시한 필드만이다 (POSE·GAIT 는 자르지 않는다).
CLAMP_RANGES: dict[str, tuple[float, float]] = {
    "step": (-100, 100),  # mm
    # deg — arc 조향. `step=0` 제자리 회전은 경로 제어에 쓰지 않는다 (ADR-11).
    "angle": (-30, 30),
    "id": (0, 15),  # 내장 액션 그룹
}

#: FSM 상태 — 명령(`STATE`)과 텔레메트리(`state`) 양쪽에서 쓴다. 모르는 상태는 폐기 + WARN.
#:
#: FSM 은 Host PC 에서 돈다. 온보드가 스스로 아는 것은 `ONBOARD_STATES` 셋뿐이고, 나머지는
#: 호스트가 `STATE` 로 내려보낸 것을 로봇이 되돌려준다. 정본은 아키텍처 문서의 전이표이며
#: `test_fsm_states_match_the_transition_table` 이 대조한다.
FSM_STATES: frozenset[str] = frozenset(
    {
        # ── 온보드가 센서만으로 판정 가능 (Tier 1) ──
        "PATROL",
        "AVOID",
        "FAILSAFE",
        # ── 호스트 FSM 전용 — `STATE` 명령으로 내려온다 (Tier 2) ──
        "IDLE",
        "SCAN",
        "ALERT",
        "TRACK",
        "LOST",
        "AUTH_WAIT",
        "MANUAL",
        # ── Phase 2 — 측위가 확보된 뒤에 쓰인다 ──
        "HAZARD_DISPATCH",
        "HAZARD_SCAN",
        "ZONE_INSPECT",
    }
)

#: 온보드가 센서만으로 판정할 수 있는 상태. 나머지는 호스트가 알려줘야 한다.
ONBOARD_STATES: frozenset[str] = frozenset({"PATROL", "AVOID", "FAILSAFE"})

#: 텔레메트리 필수 필드 — 안전 판단과 장애 분석에 필요한 최소 레코드다.
TELEMETRY_REQUIRED: tuple[str, ...] = (
    "seq",
    "ts",
    "device_id",
    "boot_id",
    "state",
    "dist_cm",
    "imu",
    "batt_v",
    "last_cmd_age_ms",
    "flags",
)
IMU_FIELDS: tuple[str, ...] = ("pitch", "roll", "yaw")
FLAG_FIELDS: tuple[str, ...] = ("lowbatt", "tipped", "link_ok")

#: 있으면 검사하고 없으면 넘어가는 하위 호환 플래그. `obstacle` 은 «온보드 근거리 반사
#: 정지가 지금 걸려 있는가» 다 — 반향될 수 있는 `state` 로는 해제를 알 수 없다 (ADR-22).
OPTIONAL_FLAG_FIELDS: tuple[str, ...] = ("obstacle", "service")

#: `TelemetryEncoder` 가 스스로 채우며 `extra` 로 덮을 수 없는 필드 (본문 필드는 명명 인자다).
TELEMETRY_MANAGED: frozenset[str] = frozenset({"seq", "ts", "device_id", "boot_id"})

#: 2S 리튬 물리 범위. 이 밖의 값은 측정 오류로 폐기한다 — 저전압 판정 임계
#: (`config.safety.battery_*`)와는 별개다 (ADR-30).
BATT_MIN_V: float = 6.0
#: 만충 8.4V 에 측정 여유 0.2V 를 더한 상한 (ADR-30).
BATT_MAX_V: float = 8.6

#: 메타 필드 — 픽스처의 주석용이며 전송 대상이 아니다.
META_FIELDS: frozenset[str] = frozenset({"_case", "_expect"})


# ══════════════════════════════════════════════════════════════
#  2. 판정 결과
# ══════════════════════════════════════════════════════════════


class Verdict(StrEnum):
    """수신 판정. 값은 골든 픽스처의 `_expect` 와 문자열까지 일치한다."""

    ACCEPT = "accept"
    CLAMP = "clamp"  # 받아들이되 범위를 잘랐다
    DISCARD = "discard"
    DISCARD_WARN = "discard_warn"  # 폐기 + WARN 로그 (규약 확장의 근거)


@dataclass(frozen=True, slots=True)
class DecodeResult:
    """파싱·검증 결과. 로깅과 부수효과는 호출자의 몫이다."""

    verdict: Verdict
    reason: str = ""
    message: dict[str, Any] | None = None
    clamped: tuple[str, ...] = ()

    @property
    def accepted(self) -> bool:
        return self.verdict in (Verdict.ACCEPT, Verdict.CLAMP)

    @property
    def warns(self) -> bool:
        return self.verdict is Verdict.DISCARD_WARN

    @property
    def refreshes_link(self) -> bool:
        """규칙 ③ — 받아들인 패킷만 링크 타임아웃을 갱신한다. 수신 루프는 이 값만 본다."""
        return self.accepted


def _accept(msg: dict[str, Any], clamped: tuple[str, ...]) -> DecodeResult:
    verdict = Verdict.CLAMP if clamped else Verdict.ACCEPT
    return DecodeResult(verdict, message=msg, clamped=clamped)


# ══════════════════════════════════════════════════════════════
#  3. 공통 도구
# ══════════════════════════════════════════════════════════════


def system_clock_ms() -> int:
    """Host PC 기준 epoch 밀리초. 이 파일에서 실제 시각을 읽는 유일한 지점이다."""
    return int(time.time() * 1000)


def _is_number(value: Any) -> TypeGuard[int | float]:
    """bool·NaN·무한대는 수치로 보지 않는다."""
    if not isinstance(value, int | float) or isinstance(value, bool):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def _is_int(value: Any) -> bool:
    """정수 필드 검사. 실수를 받으면 순서 게이트와 메시지의 seq 가 어긋나므로 거부한다."""
    # C++ 파서가 double로 읽어도 정확히 표현할 수 있는 정수만 전송한다.
    return isinstance(value, int) and not isinstance(value, bool) and abs(value) < 1 << 53


def _known(value: Any, allowed: frozenset[str]) -> bool:
    """문자열인지 먼저 확인한 뒤 목록과 대조한다.

    ⚠️ 순서를 바꾸지 않는다 — `{"type": []}` 같은 해시 불가 값이 `TypeError` 로 수신 루프를 죽인다.
    """
    return isinstance(value, str) and value in allowed


def _command_field_error(type_: str, fields: dict[str, Any]) -> str | None:
    """타입별 필드의 자료형과 최소 의미 범위를 검사한다."""
    for name in REQUIRED_FIELDS[type_]:
        value = fields[name]
        if name in STRING_FIELDS:
            if not isinstance(value, str):
                return f"{name} 가 문자열이 아님"
        elif not _is_number(value):
            return f"{name} 가 유한한 수가 아님"
        elif name in INTEGER_FIELDS and not _is_int(value):
            return f"{name} 가 정수가 아님"
        elif name in INTEGER_FIELDS - {"id"} and value > (1 << 31) - 1:
            return f"{name} 가 32비트 정수 범위를 초과함"
        elif name in {"pitch", "roll", "height", "blink_hz"} and abs(value) > 3.4028234663852886e38:
            return f"{name} 가 32비트 실수 범위를 초과함"
    for name in NONNEGATIVE_FIELDS.get(type_, ()):
        if fields[name] < 0:
            return f"{name} 가 음수"
    return None


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def apply_clamps(msg: dict[str, Any]) -> tuple[dict[str, Any], tuple[str, ...]]:
    """범위를 벗어난 필드를 잘라 새 dict 로 돌려준다 (규칙 ② · PROTOCOL.md 3절)."""
    out = dict(msg)
    clamped: list[str] = []
    for name, (low, high) in CLAMP_RANGES.items():
        value = out.get(name)
        if not _is_number(value):
            continue
        limited = clamp(value, low, high)
        if limited != value:
            out[name] = limited
            clamped.append(name)
    return out, tuple(sorted(clamped))


def serialize(msg: dict[str, Any]) -> str:
    """한 줄 JSON 으로 만든다. 줄바꿈이 없어야 JSONL·UDP 양쪽에서 안전하다."""
    return json.dumps(msg, separators=(",", ":"), ensure_ascii=False, allow_nan=False)


def strip_meta(msg: dict[str, Any]) -> dict[str, Any]:
    """픽스처의 `_case`·`_expect` 를 걷어낸다. 전송 대상이 아니다."""
    return {k: v for k, v in msg.items() if k not in META_FIELDS}


def _parse(raw: str | bytes) -> dict[str, Any] | DecodeResult:
    try:
        msg = json.loads(raw)
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError, RecursionError):
        # 규칙 ③ — 폐기하되 타임아웃 카운터를 갱신하지 않는다.
        return DecodeResult(Verdict.DISCARD, "파싱 실패")
    if not isinstance(msg, dict):
        return DecodeResult(Verdict.DISCARD, "최상위가 JSON 객체가 아님")
    return msg


class _SeqGate:
    """seq 역전·중복 폐기 (규칙 ①). 여러 개체를 동시에 운용하므로 송신자별로 센다."""

    def __init__(self) -> None:
        self._last: dict[Hashable, int] = {}

    def last_seq(self, sender: Hashable = "") -> int | None:
        return self._last.get(sender)

    def reset(self, sender: Hashable = "") -> None:
        self._last.pop(sender, None)

    def admit(self, seq: int, sender: Hashable = "") -> bool:
        last = self._last.get(sender)
        if last is not None and seq <= last:
            return False
        self._last[sender] = seq
        return True


# ══════════════════════════════════════════════════════════════
#  4. 제어 명령 — Host PC → MechDog
# ══════════════════════════════════════════════════════════════


class CommandEncoder:
    """제어 명령 직렬화. `seq` 는 단조 증가하고 `ts` 는 주입된 시계에서 온다.

    송신은 10Hz 고정이며 변화가 없어도 보낸다 — 그것이 하트비트다 (PROTOCOL.md 1절).
    """

    def __init__(self, clock: Callable[[], int] = system_clock_ms, start_seq: int = 1) -> None:
        if not _is_int(start_seq) or start_seq < 1:
            raise ValueError("start_seq 는 1 이상의 정수여야 함")
        self._clock = clock
        self._seq = start_seq

    @property
    def next_seq(self) -> int:
        return self._seq

    def build(self, type_: str, **fields: Any) -> dict[str, Any]:
        """명령 dict 를 만든다. 범위를 벗어난 값은 자르고, 모르는 타입·필드 누락은
        송신측 버그이므로 `ValueError` 를 낸다."""
        if type_ not in COMMAND_TYPES:
            raise ValueError(f"알 수 없는 명령 타입: {type_!r}")
        # 예약 키로 자동 생성값을 덮으면 단조 증가 seq 보장이 깨진다.
        reserved = COMMON_REQUIRED_SET & fields.keys()
        if reserved:
            raise ValueError(f"인코더가 관리하는 필드는 넘길 수 없다: {sorted(reserved)}")
        missing = REQUIRED_FIELDS[type_] - fields.keys()
        if missing:
            raise ValueError(f"{type_} 필수 필드 누락: {sorted(missing)}")
        if type_ == "STATE" and not _known(fields["state"], FSM_STATES):
            raise ValueError(f"알 수 없는 상태: {fields['state']!r}")
        if type_ == "SERVICE" and not _known(fields["mode"], SERVICE_MODES):
            raise ValueError(f"알 수 없는 서비스 모드: {fields['mode']!r}")
        if error := _command_field_error(type_, fields):
            raise ValueError(error)

        if not _is_int(self._seq):
            raise ValueError("seq 범위 소진: 새 세션으로 연결해야 함")
        timestamp = self._clock()
        if not _is_int(timestamp) or timestamp < 0:
            raise ValueError("clock 은 0 이상의 epoch 밀리초 정수를 반환해야 함")
        msg = {"seq": self._seq, "ts": timestamp, "type": type_, **fields}
        self._seq += 1
        msg, _ = apply_clamps(msg)
        return msg

    def encode(self, type_: str, **fields: Any) -> str:
        return serialize(self.build(type_, **fields))

    # ── 편의 메서드 ── 호출부가 필드명을 외우지 않아도 되게 한다
    def move(self, step: float, angle: float) -> str:
        return self.encode("MOVE", step=step, angle=angle)

    def pose(self, pitch: float, roll: float, height: float, dur: int) -> str:
        return self.encode("POSE", pitch=pitch, roll=roll, height=height, dur=dur)

    def gait(self, lift_time: int, ground_time: int, height: float) -> str:
        return self.encode("GAIT", lift_time=lift_time, ground_time=ground_time, height=height)

    def stop(self) -> str:
        return self.encode("STOP")

    def estop(self) -> str:
        """온보드 FAILSAFE를 래치한다. 일반 STOP으로는 해제되지 않는다."""
        return self.encode("ESTOP")

    def reset_safe(self) -> str:
        """원인 해소 후 사용자 확인에 의해서만 호출한다. 복귀 상태는 IDLE."""
        return self.encode("RESET_SAFE")

    def action(self, action_id: int) -> str:
        return self.encode("ACTION", id=action_id)

    def led(self, color: str, blink_hz: float) -> str:
        return self.encode("LED", color=color, blink_hz=blink_hz)

    def sound(self, track: int) -> str:
        return self.encode("SOUND", track=track)

    def state(self, state: str) -> str:
        """호스트의 FSM 상태를 로봇에게 알려준다. 로봇은 되돌려줄 뿐 판단에 쓰지 않으며,
        Tier 1 온보드 안전 판정이 이 값보다 우선한다 (아키텍처 1.2)."""
        return self.encode("STATE", state=state)

    def service(self, mode: str) -> str:
        """SERVICE 모드 전환 — 루프 워치독을 단 런타임 진입/해제.

        `enter` 는 몸을 주차(safe 래치 + 보행 차단)한 뒤 워치독을 걸고,
        `exit` 는 워치독을 해제한다. 해제 후에도 safe 래치는 남으므로
        보행 복귀에는 `RESET_SAFE` 가 필요하다.
        """
        return self.encode("SERVICE", mode=mode)


class CommandDecoder:
    """제어 명령 수신 검증 — 가상 MechDog 가 쓰는 펌웨어 참조 구현.

    C++ 파서와 규칙·순서가 같아야 한다. 순서는 PROTOCOL.md 3절 ①~④ 를 실행 가능하게 편 것이다.
    """

    def __init__(self) -> None:
        self._gate = _SeqGate()
        self._latest_ts: int | None = None
        self._session_started_ts: int | None = None

    @property
    def last_seq(self) -> int | None:
        return self._gate.last_seq()

    def decode(self, raw: str | bytes) -> DecodeResult:
        parsed = _parse(raw)
        if isinstance(parsed, DecodeResult):
            return parsed
        return self.validate(parsed)

    def validate(self, msg: dict[str, Any]) -> DecodeResult:
        msg = strip_meta(msg)

        for key in COMMON_REQUIRED:
            if key not in msg:
                return DecodeResult(Verdict.DISCARD, f"공통 필수 필드 누락: {key}")
        for key in ("seq", "ts"):
            if not _is_int(msg[key]):
                return DecodeResult(Verdict.DISCARD, f"{key} 가 정수가 아님")
        if msg["seq"] < 1 or msg["ts"] < 0:
            return DecodeResult(Verdict.DISCARD, "seq 또는 ts 가 음수 범위")
        if not isinstance(msg["type"], str):
            return DecodeResult(Verdict.DISCARD, "type 이 문자열이 아님")

        # Host 재시작 핸드셰이크. 새 프로세스는 STOP seq=1 로 시작하며,
        # 이전 세션보다 새 시각일 때만 게이트를 연다. 이후 지연 도착한 옛
        # 데이터그램은 세션 시작 시각으로 한 번 더 막는다.
        if self._session_started_ts is not None and msg["ts"] < self._session_started_ts:
            return DecodeResult(Verdict.DISCARD, "이전 Host 세션의 패킷")
        if (
            self._gate.last_seq() is not None
            and msg["seq"] == 1
            and msg["type"] == "STOP"
            and (self._latest_ts is None or msg["ts"] > self._latest_ts)
        ):
            self._gate.reset()
            self._session_started_ts = msg["ts"]

        # ① seq 역전·중복
        if not self._gate.admit(msg["seq"]):
            return DecodeResult(Verdict.DISCARD, "seq 역전·중복")
        self._latest_ts = max(self._latest_ts or msg["ts"], msg["ts"])

        # ④ 모르는 타입 — 폐기 + WARN
        type_ = msg["type"]
        if type_ not in COMMAND_TYPES:
            return DecodeResult(Verdict.DISCARD_WARN, f"알 수 없는 타입: {type_!r}")

        for name in sorted(REQUIRED_FIELDS[type_]):
            if name not in msg:
                return DecodeResult(Verdict.DISCARD, f"{type_} 필수 필드 누락: {name}")
        if error := _command_field_error(type_, msg):
            return DecodeResult(Verdict.DISCARD, error)

        # 모르는 상태값 — 폐기 + WARN (텔레메트리 규칙 ③과 대칭).
        if type_ == "STATE" and not _known(msg["state"], FSM_STATES):
            return DecodeResult(Verdict.DISCARD_WARN, f"알 수 없는 상태: {msg['state']!r}")
        if type_ == "SERVICE" and not _known(msg["mode"], SERVICE_MODES):
            return DecodeResult(Verdict.DISCARD_WARN, f"알 수 없는 서비스 모드: {msg['mode']!r}")

        # ② 범위 초과는 폐기가 아니라 클램핑
        return _accept(*apply_clamps(msg))


# ══════════════════════════════════════════════════════════════
#  5. 텔레메트리 — MechDog → Host PC
# ══════════════════════════════════════════════════════════════


class TelemetryEncoder:
    """텔레메트리 직렬화 — 펌웨어(C++)의 대응물이며 가상 MechDog 가 쓴다."""

    def __init__(
        self,
        device_id: str,
        boot_id: str,
        clock: Callable[[], int] = system_clock_ms,
        start_seq: int = 1,
    ) -> None:
        if not isinstance(device_id, str) or not device_id:
            raise ValueError("device_id 는 필수다 — IP 로 송신자를 구분하면 안 된다 (DR-17)")
        if not isinstance(boot_id, str) or not boot_id or len(boot_id) > 64:
            raise ValueError("boot_id 는 1~64자의 문자열이어야 함")
        if not _is_int(start_seq) or start_seq < 1:
            raise ValueError("start_seq 는 1 이상의 정수여야 함")
        self._device_id = device_id
        self._boot_id = boot_id
        self._clock = clock
        self._seq = start_seq

    @property
    def next_seq(self) -> int:
        return self._seq

    def build(
        self,
        state: str,
        dist_cm: float,
        imu: dict[str, float],
        batt_v: float,
        last_cmd_age_ms: int,
        flags: dict[str, bool],
        **extra: Any,
    ) -> dict[str, Any]:
        if not _known(state, FSM_STATES):
            raise ValueError(f"알 수 없는 상태: {state!r}")
        missing_imu = [f for f in IMU_FIELDS if f not in imu]
        if missing_imu:
            raise ValueError(f"imu 필드 누락: {missing_imu}")
        missing_flags = [f for f in FLAG_FIELDS if f not in flags]
        if missing_flags:
            raise ValueError(f"flags 필드 누락: {missing_flags}")
        if not _is_number(dist_cm) or dist_cm < 0:
            raise ValueError("dist_cm 은 0 이상의 유한한 수여야 한다")
        if not _is_number(batt_v) or not BATT_MIN_V <= batt_v <= BATT_MAX_V:
            raise ValueError(f"batt_v 물리 범위 이탈: {batt_v}")
        if not _is_int(last_cmd_age_ms) or last_cmd_age_ms < 0:
            raise ValueError("last_cmd_age_ms 는 0 이상의 정수여야 한다")
        for name in IMU_FIELDS:
            if not _is_number(imu[name]):
                raise ValueError(f"imu.{name} 가 유한한 수가 아님")
        if not 0 <= imu["yaw"] < 360:
            raise ValueError("imu.yaw 는 0 이상 360 미만이어야 한다")
        for name in FLAG_FIELDS:
            if not isinstance(flags[name], bool):
                raise ValueError(f"flags.{name} 가 불리언이 아님")
        # `extra` 로 `device_id` 등을 덮으면 송신자를 위조할 수 있다.
        reserved = TELEMETRY_MANAGED & extra.keys()
        if reserved:
            raise ValueError(f"인코더가 관리하는 필드는 넘길 수 없다: {sorted(reserved)}")

        if not _is_int(self._seq):
            raise ValueError("seq 범위 소진: 새 세션으로 연결해야 함")
        timestamp = self._clock()
        if not _is_int(timestamp) or timestamp < 0:
            raise ValueError("clock 은 0 이상의 epoch 밀리초 정수를 반환해야 함")
        msg = {
            "seq": self._seq,
            "ts": timestamp,
            "device_id": self._device_id,
            "boot_id": self._boot_id,
            "state": state,
            "dist_cm": dist_cm,
            "imu": dict(imu),
            "batt_v": batt_v,
            "last_cmd_age_ms": last_cmd_age_ms,
            "flags": dict(flags),
            **extra,
        }
        self._seq += 1
        return msg

    def encode(self, *args: Any, **kwargs: Any) -> str:
        return serialize(self.build(*args, **kwargs))


class TelemetryDecoder:
    """텔레메트리 수신 검증 (PROTOCOL.md 5절). 규칙은 제어 명령 쪽과 대칭이다."""

    def __init__(self) -> None:
        self._gate = _SeqGate()

    @staticmethod
    def _session_key(device_id: str, boot_id: str) -> tuple[str, str]:
        return device_id, boot_id

    def last_seq(self, device_id: str, boot_id: str) -> int | None:
        """해당 개체의 **한 부팅 세션**에서 마지막으로 받은 seq."""
        return self._gate.last_seq(self._session_key(device_id, boot_id))

    def forget_session(self, device_id: str, boot_id: str) -> None:
        """시험·명시적 세션 폐기용. 정상 재부팅은 새 boot_id 로 자동 분리된다."""
        self._gate.reset(self._session_key(device_id, boot_id))

    def decode(self, raw: str | bytes) -> DecodeResult:
        parsed = _parse(raw)
        if isinstance(parsed, DecodeResult):
            return parsed
        return self.validate(parsed)

    def validate(self, msg: dict[str, Any]) -> DecodeResult:
        msg = strip_meta(msg)

        # ② 필수 필드
        for key in TELEMETRY_REQUIRED:
            if key not in msg:
                return DecodeResult(Verdict.DISCARD, f"필수 필드 누락: {key}")
        if not _is_int(msg["seq"]):
            return DecodeResult(Verdict.DISCARD, "seq 가 정수가 아님")
        if not _is_int(msg["ts"]):
            return DecodeResult(Verdict.DISCARD, "ts 가 정수가 아님")
        if msg["seq"] < 1 or msg["ts"] < 0:
            return DecodeResult(Verdict.DISCARD, "seq 또는 ts 가 음수 범위")
        if not isinstance(msg["device_id"], str) or not msg["device_id"]:
            return DecodeResult(Verdict.DISCARD, "device_id 가 비어 있음")
        if not isinstance(msg["boot_id"], str) or not msg["boot_id"] or len(msg["boot_id"]) > 64:
            return DecodeResult(Verdict.DISCARD, "boot_id 가 비어 있거나 64자를 초과함")

        imu, flags = msg["imu"], msg["flags"]
        if not isinstance(imu, dict) or not isinstance(flags, dict):
            return DecodeResult(Verdict.DISCARD, "imu·flags 가 객체가 아님")
        for name in IMU_FIELDS:
            if not _is_number(imu.get(name)):
                return DecodeResult(Verdict.DISCARD, f"imu.{name} 누락 또는 비수치")
        if not 0 <= imu["yaw"] < 360:
            return DecodeResult(Verdict.DISCARD, f"imu.yaw 범위 이탈: {imu['yaw']}")
        for name in FLAG_FIELDS:
            if not isinstance(flags.get(name), bool):
                return DecodeResult(Verdict.DISCARD, f"flags.{name} 누락 또는 비불리언")
        for name in OPTIONAL_FLAG_FIELDS:
            if name in flags and not isinstance(flags[name], bool):
                return DecodeResult(Verdict.DISCARD, f"flags.{name} 가 불리언이 아님")

        # ① seq 역전·중복 — 개체와 부팅 세션별로 센다. ESP32가 재부팅해
        # seq=1로 돌아와도 새 boot_id이면 즉시 받아들인다.
        session_key = self._session_key(msg["device_id"], msg["boot_id"])
        if not self._gate.admit(msg["seq"], session_key):
            return DecodeResult(Verdict.DISCARD, "seq 역전·중복")

        # ③ 모르는 상태 — 폐기 + WARN. WARN 은 «새 상태가 생겼다» 는 신호이므로
        # 문자열이 아닌 기형 값은 조용히 폐기한다.
        state = msg["state"]
        if not isinstance(state, str):
            return DecodeResult(Verdict.DISCARD, "state 가 문자열이 아님")
        if not _known(state, FSM_STATES):
            return DecodeResult(Verdict.DISCARD_WARN, f"알 수 없는 상태: {state!r}")

        # ④ 물리적으로 불가능한 값
        batt_v = msg["batt_v"]
        if not _is_number(batt_v) or not BATT_MIN_V <= batt_v <= BATT_MAX_V:
            return DecodeResult(Verdict.DISCARD, f"batt_v 물리 범위 이탈: {batt_v}")
        dist_cm = msg["dist_cm"]
        if not _is_number(dist_cm) or dist_cm < 0:
            return DecodeResult(Verdict.DISCARD, f"dist_cm 음수: {dist_cm}")
        last_cmd_age_ms = msg["last_cmd_age_ms"]
        if not _is_int(last_cmd_age_ms) or last_cmd_age_ms < 0:
            return DecodeResult(Verdict.DISCARD, "last_cmd_age_ms 가 0 이상의 정수가 아님")

        # ⑤ 플래그와 상태의 모순 — 안전측으로 폐기 + WARN. `tipped` 면 state 는 FAILSAFE
        # 여야 한다 (`lowbatt` 는 경고 수준이라 PATROL 과 공존한다).
        if flags["tipped"] and state != "FAILSAFE":
            return DecodeResult(Verdict.DISCARD_WARN, f"tipped 인데 state={state}")

        return _accept(msg, ())
