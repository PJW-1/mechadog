"""PPE 재학습 도구(`tools/ppe/`)의 순수 규칙 검증.

⚠️ **torch·yolox·모델 파일 없이 돈다.** 학습 환경은 저장소 밖에 있고 CI 에는 없다.
여기서 지키는 것은 추론이 아니라 **데이터 규칙**이다 — 매핑표에 없는 이름이면 멈추는가,
크롭이 런타임과 같은가, 부분 라벨 사람을 빼는가, 세션 프레임이 test 로 새지 않는가.
"""

from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from host.vision.detector import Detection  # noqa: E402
from tools.ppe import export_ppe, rf100_prepare, xiao_hardcases  # noqa: E402
from tools.ppe.ppe_live_check import (  # noqa: E402
    DEFAULT_ACCEPTANCE_PLAN,
    STATE_OK,
    STATE_VIOLATION,
    crop_person,
    load_acceptance_plan,
)

PERSON = (10.0, 20.0, 50.0, 120.0)  # 폭 40 · 높이 100
HELMET = (22.0, 18.0, 38.0, 34.0)  # 머리 — 사람 박스 위로 조금 삐져나옴
VEST = (14.0, 50.0, 46.0, 90.0)  # 몸통 55~70% 구간


# ── rf100_prepare: 이름 매핑 ─────────────────────────────────
def test_mapping_normalizes_roboflow_spellings():
    cats = [
        {"id": 0, "name": "workers", "supercategory": "none"},
        {"id": 1, "name": "Helmet", "supercategory": "workers"},
        {"id": 2, "name": "No-Helmet", "supercategory": "workers"},
        {"id": 3, "name": "no vest", "supercategory": "workers"},
        {"id": 4, "name": "vest", "supercategory": "workers"},
        {"id": 5, "name": "person", "supercategory": "workers"},
    ]
    assert rf100_prepare.map_categories(cats) == {
        0: None,
        1: "helmet",
        2: "no_helmet",
        3: "no_vest",
        4: "vest",
        5: "person",
    }


def test_mapping_stops_on_unknown_name():
    cats = [{"id": 1, "name": "helmet"}, {"id": 2, "name": "gloves"}]
    with pytest.raises(SystemExit, match="gloves"):
        rf100_prepare.map_categories(cats, "x.json")


# ── rf100_prepare: 크롭 좌표와 50% 규칙 ──────────────────────
def test_crop_rect_matches_runtime_crop():
    image = np.zeros((200, 100, 3), dtype=np.uint8)
    for pad in (0.0, 0.08, 0.2):
        crop, (left, top) = crop_person(image, PERSON, pad)
        rect = rf100_prepare.crop_rect(100, 200, PERSON, pad)
        assert rect == (left, top, left + crop.shape[1], top + crop.shape[0])
    # 경계 클램프
    assert rf100_prepare.crop_rect(100, 200, (0, 0, 100, 200), 0.08) == (0, 0, 100, 200)
    # 너무 작으면 런타임처럼 실패
    assert rf100_prepare.crop_rect(100, 200, (10, 10, 14, 14), 0.0) is None


def test_to_crop_shifts_and_drops_boxes_under_half():
    rect = (10.0, 20.0, 60.0, 120.0)
    assert rf100_prepare.to_crop((20, 30, 30, 40), rect) == (10, 10, 20, 20)
    # 60% 남음 → 잘라서 남긴다
    assert rf100_prepare.to_crop((54, 30, 64, 40), rect) == (44, 10, 50, 20)
    # 40% 남음 → 버린다
    assert rf100_prepare.to_crop((56, 30, 66, 40), rect) is None


# ── rf100_prepare: 부분 라벨 검사 ────────────────────────────
def test_person_label_check_requires_head_and_torso():
    check = rf100_prepare.person_label_problem
    assert check(PERSON, [("helmet", HELMET), ("no_vest", VEST)]) is None
    assert check(PERSON, [("vest", VEST)]) == rf100_prepare.REASON_NO_HEAD
    assert check(PERSON, [("no_helmet", HELMET)]) == rf100_prepare.REASON_NO_TORSO
    # 몸통 라벨이 머리 자리에 있으면 몸통 라벨로 보지 않는다
    assert check(PERSON, [("helmet", HELMET), ("vest", HELMET)]) == rf100_prepare.REASON_NO_TORSO
    # 다른 사람의 머리(가로로 벗어남)는 이 사람 머리가 아니다
    far_head = (70.0, 18.0, 86.0, 34.0)
    assert check(PERSON, [("helmet", far_head), ("vest", VEST)]) == rf100_prepare.REASON_NO_HEAD


# ── rf100_prepare: 가짜 COCO 로 끝까지 ──────────────────────
def _write_image(path: Path, seed: int) -> None:
    import cv2

    rng = np.random.default_rng(seed)
    image = rng.integers(0, 255, (200, 100, 3), dtype=np.uint8)
    path.parent.mkdir(parents=True, exist_ok=True)
    assert cv2.imwrite(str(path), image)


def _fake_split(folder: Path, images: list[tuple[str, int, list]]) -> None:
    cats = [
        {"id": 0, "name": "workers", "supercategory": "none"},
        {"id": 1, "name": "helmet", "supercategory": "workers"},
        {"id": 2, "name": "no-vest", "supercategory": "workers"},
        {"id": 3, "name": "vest", "supercategory": "workers"},
        {"id": 4, "name": "person", "supercategory": "workers"},
    ]
    coco = {"images": [], "annotations": [], "categories": cats}
    for image_id, (name, seed, anns) in enumerate(images, 1):
        _write_image(folder / name, seed)
        coco["images"].append({"id": image_id, "file_name": name, "width": 100, "height": 200})
        for cat, (x1, y1, x2, y2) in anns:
            coco["annotations"].append(
                {
                    "id": len(coco["annotations"]) + 1,
                    "image_id": image_id,
                    "category_id": cat,
                    "bbox": [x1, y1, x2 - x1, y2 - y1],
                }
            )
    (folder / "_annotations.coco.json").write_text(json.dumps(coco), encoding="utf-8")


def _fake_raw(root: Path, license_line: str = "License: CC BY 4.0") -> Path:
    raw = root / "raw"
    full = [(4, PERSON), (1, HELMET), (3, VEST)]
    no_head = [(4, PERSON), (2, VEST)]
    _fake_split(raw / "test", [("t1.jpg", 1, full)])
    _fake_split(raw / "valid", [("v1.jpg", 2, full)])
    # 1번 사진은 test 와 바이트가 같다 → 학습 쪽에서 빠진다. 2번은 머리 라벨이 없다.
    _fake_split(raw / "train", [("a.jpg", 1, full), ("b.jpg", 3, no_head), ("c.jpg", 4, full)])
    (raw / "README.roboflow.txt").write_text(
        f"https://universe.roboflow.com/example/construction-safety\n{license_line}\n",
        encoding="utf-8",
    )
    return raw


def test_prepare_builds_yolox_layout_and_card(tmp_path):
    raw = _fake_raw(tmp_path)
    out = tmp_path / "build" / "v0"
    card = rf100_prepare.prepare(raw, out, "v0", seed=1)

    for split, folder in rf100_prepare.IMAGE_DIRS.items():
        ann = out / "annotations" / f"instances_{split}.json"
        # pycocotools 는 인코딩 없이 open() 한다 — Windows(cp949)에서 한글이 있으면 학습이 멈춘다
        ann.read_bytes().decode("ascii")
        coco = json.loads(ann.read_text("utf-8"))
        # 카테고리 id 순서 = 우리 4클래스 순서 (YOLOX 는 id 를 정렬해 클래스 번호로 쓴다)
        assert [c["name"] for c in sorted(coco["categories"], key=lambda c: c["id"])] == list(
            rf100_prepare.CLASSES
        )
        for image in coco["images"]:
            assert (out / folder / image["file_name"]).is_file()
    stats = card["splits"]
    assert stats["train"]["duplicates"] == 1
    assert stats["train"]["excluded"] == {rf100_prepare.REASON_NO_HEAD: 1}
    assert stats["train"]["images"] == 1
    assert stats["test"]["boxes"] == {"helmet": 1, "vest": 1}
    assert card["source"]["license"] == "CC BY 4.0"
    assert (out / "data_card.json").is_file()

    # 검증·시험은 런타임 여유(0.08) 그대로 자른다
    val = json.loads((out / "annotations" / "instances_val.json").read_text("utf-8"))
    rect = rf100_prepare.crop_rect(100, 200, PERSON, rf100_prepare.RUNTIME_PAD)
    assert (val["images"][0]["width"], val["images"][0]["height"]) == (
        rect[2] - rect[0],
        rect[3] - rect[1],
    )


def test_prepare_refuses_non_commercial_license(tmp_path):
    raw = _fake_raw(tmp_path, "License: CC BY-NC 4.0")
    with pytest.raises(SystemExit, match="라이선스"):
        rf100_prepare.prepare(raw, tmp_path / "out", "v0")


# ── xiao_hardcases ──────────────────────────────────────────
def test_relabel_all_worn_truth_turns_violations_into_worn_and_dedupes():
    found = [
        Detection("no_helmet", 0.8, (10, 10, 30, 30)),
        Detection("helmet", 0.6, (11, 10, 31, 30)),  # 같은 머리
        Detection("no_vest", 0.7, (5, 40, 40, 90)),
        Detection("class_4", 0.9, (0, 0, 50, 100)),  # 5클래스 모델의 5번째
    ]
    out = xiao_hardcases.relabel_by_truth(found, helmet=True, vest=True)
    assert sorted((d.label, d.score) for d in out) == [
        ("helmet", pytest.approx(0.8)),
        ("vest", pytest.approx(0.7)),
    ]
    assert xiao_hardcases.has_head_and_torso(out)
    assert not xiao_hardcases.has_head_and_torso(out[:1])


def _xiao_truths():
    specs, _, _ = load_acceptance_plan(DEFAULT_ACCEPTANCE_PLAN, "xiao")
    return xiao_hardcases.segment_truths(specs)


def test_segment_truths_reads_wear_from_acceptance_plan():
    """착용 조합 8구간(직립·웅크림 × 4)을 쓰고, 확인불가·로봇 자세 구간은 이유와 함께 뺀다."""
    used, excluded = _xiao_truths()
    assert set(used) == {
        f"{pose}-{wear}"
        for pose in ("standing", "crouching")
        for wear in ("all", "nohelmet", "novest", "none")
    }
    assert (used["standing-all"].helmet, used["standing-all"].vest) == (True, True)
    assert (used["crouching-nohelmet"].helmet, used["crouching-nohelmet"].vest) == (False, True)
    assert (used["standing-novest"].helmet, used["standing-novest"].vest) == (True, False)
    assert (used["crouching-none"].helmet, used["crouching-none"].vest) == (False, False)
    assert used["standing-none"].expected == STATE_VIOLATION
    assert set(excluded) == {"clipped-base", "pitch-up", "sit"}
    assert "확인불가" in excluded["clipped-base"]
    assert "로봇 자세" in excluded["pitch-up"] and "로봇 자세" in excluded["sit"]


def test_segment_truths_refuses_unknown_wear_and_inconsistent_expectation():
    specs = [
        {"key": "a", "condition": "직립·전신", "wear": "모자만", "expected": STATE_VIOLATION},
        {"key": "b", "condition": "직립·전신", "wear": "안전모 미착용", "expected": STATE_OK},
        {"key": "c", "condition": "직립·전신", "wear": "전부 착용", "expected": STATE_VIOLATION},
    ]
    used, excluded = xiao_hardcases.segment_truths(specs)
    assert used == {}
    assert "착용 문구" in excluded["a"]
    assert "어긋" in excluded["b"] and "어긋" in excluded["c"]


def test_truth_events_keeps_known_segments_with_people():
    used, _ = _xiao_truths()
    events = [
        {"t": 1.0, "tag": "00001", "people": 1, "segment": None, "expected": None},
        {"t": 2.0, "tag": "00002", "people": 1, "segment": "standing-all", "expected": STATE_OK},
        {"t": 3.0, "tag": "00003", "people": 0, "segment": "standing-none", "expected": "위반"},
        {"t": 4.0, "tag": "00004", "people": 1, "segment": "standing-none", "expected": "위반"},
        {"t": 5.0, "tag": "00005", "people": 1, "segment": "pitch-up", "expected": STATE_OK},
        {"t": 6.0, "tag": "00006", "people": 1, "segment": "clipped-base", "expected": "확인불가"},
    ]
    assert [e["tag"] for e in xiao_hardcases.truth_events(events, used)] == ["00002", "00004"]


def test_truth_events_stops_when_plan_disagrees_with_session():
    """세션이 기록한 기대 판정과 지금 구간 정의가 다르면 정의가 바뀐 것이다 — 멈춘다."""
    used, _ = _xiao_truths()
    events = [{"t": 1.0, "tag": "1", "people": 1, "segment": "standing-novest", "expected": "적합"}]
    with pytest.raises(SystemExit):
        xiao_hardcases.truth_events(events, used)


def test_relabel_by_truth_names_boxes_from_segment_not_model():
    found = [
        Detection("helmet", 0.8, (10, 10, 30, 30)),  # 모델은 착용이라 했지만 맨머리 구간
        Detection("no_helmet", 0.6, (11, 10, 31, 30)),  # 같은 머리
        Detection("no_vest", 0.7, (5, 40, 40, 90)),  # 조끼는 입은 구간
        Detection("class_4", 0.9, (0, 0, 50, 100)),
    ]
    out = xiao_hardcases.relabel_by_truth(found, helmet=False, vest=True)
    assert sorted((d.label, d.score) for d in out) == [
        ("no_helmet", pytest.approx(0.8)),
        ("vest", pytest.approx(0.7)),
    ]
    both_off = xiao_hardcases.relabel_by_truth(found, helmet=False, vest=False)
    assert sorted(d.label for d in both_off) == ["no_helmet", "no_vest"]
    assert xiao_hardcases.has_head_and_torso(both_off)


def test_is_hard_marks_session_or_model_disagreement_with_truth():
    helmet = Detection("helmet", 0.9, (0, 0, 1, 1))
    no_helmet = Detection("no_helmet", 0.9, (0, 0, 1, 1))
    vest = Detection("vest", 0.9, (0, 2, 1, 3))
    truth_ok = xiao_hardcases.SegmentTruth(True, True, STATE_OK)
    truth_bare = xiao_hardcases.SegmentTruth(False, True, STATE_VIOLATION)
    # 전부 착용 — 예전 규칙: 세션 위반 또는 모델이 no_* 를 냈으면 틀림
    assert not xiao_hardcases.is_hard([STATE_OK], [helmet, vest], truth_ok)
    assert xiao_hardcases.is_hard([STATE_VIOLATION], [helmet, vest], truth_ok)
    assert xiao_hardcases.is_hard([STATE_OK], [no_helmet, vest], truth_ok)
    assert not xiao_hardcases.is_hard(["확인불가"], [helmet, vest], truth_ok)
    # 맨머리 — 세션이 적합이라 했거나 모델이 helmet 을 냈으면 틀림
    assert not xiao_hardcases.is_hard([STATE_VIOLATION], [no_helmet, vest], truth_bare)
    assert xiao_hardcases.is_hard([STATE_OK], [no_helmet, vest], truth_bare)
    assert xiao_hardcases.is_hard([STATE_VIOLATION], [helmet, vest], truth_bare)


def test_relabel_by_truth_drops_boxes_outside_their_body_part():
    """모델 이름 계열만 보면 몸통·배경에 그어진 머리 박스도 라벨이 된다 — 부위로 막는다."""
    import collections

    found = [
        Detection("no_helmet", 0.7, HELMET),  # 제자리 머리
        Detection("helmet", 0.9, (14.0, 60.0, 46.0, 90.0)),  # 몸통에 그어진 «머리»
        Detection("vest", 0.8, VEST),  # 제자리 몸통
        Detection("vest", 0.6, (60.0, 20.0, 90.0, 60.0)),  # 사람 밖 배경의 «몸통»
    ]
    drops: collections.Counter = collections.Counter()
    out = xiao_hardcases.relabel_by_truth(found, True, True, person=PERSON, drops=drops)
    assert sorted((d.label, d.box) for d in out) == [("helmet", HELMET), ("vest", VEST)]
    assert drops == {xiao_hardcases.DROP_HEAD_PLACE: 1, xiao_hardcases.DROP_TORSO_PLACE: 1}


def test_relabel_by_truth_drops_head_and_torso_on_the_same_spot():
    """이름을 바꾼 뒤 같은 자리에 머리·몸통 두 계열이 있으면 어느 쪽인지 모른다 — 둘 다 버린다."""
    import collections

    spot = (12.0, 35.0, 48.0, 60.0)  # 머리·몸통 구간 경계 — 두 구간 IoA 모두 0.5 이상
    found = [
        Detection("helmet", 0.9, HELMET),
        Detection("no_helmet", 0.8, spot),
        Detection("vest", 0.7, (12.0, 36.0, 48.0, 61.0)),
    ]
    drops: collections.Counter = collections.Counter()
    out = xiao_hardcases.relabel_by_truth(found, True, True, person=PERSON, drops=drops)
    assert [(d.label, d.box) for d in out] == [("helmet", HELMET)]
    assert drops == {xiao_hardcases.DROP_CROSS: 2}
    assert not xiao_hardcases.has_head_and_torso(out)


class _FixedDetector:
    def __init__(self, results):
        self.results = results
        self.inputs = []

    def detect(self, image):
        self.inputs.append(image.shape[:2])
        return list(self.results)


def test_collect_checks_body_part_in_crop_coordinates(tmp_path):
    """PPE 박스는 크롭 좌표다 — 사람 박스를 크롭 원점만큼 옮겨서 부위를 본다."""
    frame = np.full((300, 400, 3), 90, dtype=np.uint8)
    rf100_prepare.write_jpeg(tmp_path / "raw" / "00001.jpg", frame)
    person = (100.0, 50.0, 200.0, 250.0)  # pad 0.08 → 크롭 원점 (92, 34), 크롭 안 (8,16,108,216)
    coco = _FixedDetector([Detection("person", 0.9, person)])
    ppe = _FixedDetector(
        [
            Detection("no_helmet", 0.9, (40.0, 10.0, 70.0, 40.0)),  # 크롭 안 머리
            Detection("vest", 0.8, (20.0, 90.0, 90.0, 160.0)),  # 크롭 안 몸통
            Detection("helmet", 0.7, (40.0, 100.0, 70.0, 130.0)),  # 몸통 위 «머리»
        ]
    )
    config = {"vision": {"coco": {"person_class": "person"}, "ppe": {"crop_pad": 0.08}}}
    used, _ = _xiao_truths()
    events = [{"t": 1.0, "tag": "00001", "segment": "standing-novest", "states": ["위반"]}]
    cands, stats = xiao_hardcases.collect(tmp_path, events, used, config, coco, ppe)
    assert ppe.inputs == [(232, 116)]  # 크롭이 들어갔다
    assert len(cands) == 1
    assert sorted(cands[0].boxes) == [
        ("helmet", (40.0, 10.0, 70.0, 40.0)),
        ("no_vest", (20.0, 90.0, 90.0, 160.0)),
    ]
    assert stats["dropped_boxes"] == {xiao_hardcases.DROP_HEAD_PLACE: 1}


def test_segment_table_counts_per_segment():
    used, excluded = _xiao_truths()
    events = [
        {"t": 1.0, "tag": "1", "segment": "standing-all"},
        {"t": 2.0, "tag": "2", "segment": "standing-all"},
        {"t": 3.0, "tag": "3", "segment": "standing-none"},
    ]
    cands = [
        xiao_hardcases.Candidate("1", 1.0, False, (0, 0, 1, 1), (), "standing-all"),
        xiao_hardcases.Candidate("3", 3.0, True, (0, 0, 1, 1), (), "standing-none"),
    ]
    table = xiao_hardcases.segment_table(used, excluded, events, cands, cands, ["train", "val"])
    row = table["used"]["standing-none"]
    assert row["frames"] == 1 and row["candidates"] == 1 and row["candidates_hard"] == 1
    assert row["selected"] == {"train": 0, "val": 1}
    assert row["wear"] == "둘 다 미착용"
    assert table["used"]["standing-all"]["frames"] == 2
    assert table["used"]["standing-all"]["selected"] == {"train": 1, "val": 0}
    assert table["used"]["crouching-all"]["frames"] == 0
    assert table["excluded"] == excluded


def _cand(t: float, hard: bool) -> xiao_hardcases.Candidate:
    return xiao_hardcases.Candidate(f"{int(t * 10):05d}", t, hard, (0, 0, 1, 1), ())


def test_select_frames_keeps_hard_and_enforces_gap():
    cands = [_cand(i * 0.1, hard=i in (3, 4, 30)) for i in range(100)]  # 0.0~9.9초
    chosen = xiao_hardcases.select_frames(cands, keep_ratio=0.3, min_gap_s=0.5, seed=7)
    times = [cands[i].t for i in chosen]
    assert times == sorted(times)
    assert all(b - a >= 0.5 - 1e-9 for a, b in zip(times, times[1:], strict=False))
    # 틀린 프레임은 간격이 허락하는 한 들어간다 (3·4 는 0.1초 차이라 하나만)
    hard_taken = [cands[i].tag for i in chosen if cands[i].hard]
    assert "00003" in hard_taken and "00030" in hard_taken and "00004" not in hard_taken
    assert any(not cands[i].hard for i in chosen)


def test_block_split_never_emits_test():
    times = [i * 0.5 for i in range(200)]  # 100초 · 10초 블록 10개
    splits = xiao_hardcases.split_by_block(times, block_s=10, val_ratio=0.25, seed=3)
    assert set(splits) == {"train", "val"}
    by_block: dict[int, set[str]] = {}
    for t, s in zip(times, splits, strict=True):
        by_block.setdefault(int(t // 10), set()).add(s)
    assert all(len(v) == 1 for v in by_block.values())  # 블록 하나는 한쪽에만
    assert sum(1 for v in by_block.values() if v == {"val"}) == 3
    # 블록이 하나뿐이면 전부 학습 — 검증을 만들려고 test 로 새지 않는다
    assert set(xiao_hardcases.split_by_block([1.0, 2.0], 10, 0.5)) == {"train"}


def test_overlay_fraction_detects_drawn_judgement_box():
    import cv2

    rng = np.random.default_rng(0)
    clean = rng.integers(60, 180, (240, 320, 3), dtype=np.uint8)
    drawn = clean.copy()
    cv2.rectangle(drawn, (100, 40), (180, 220), (0, 200, 0), 2)
    ok, buf = cv2.imencode(".jpg", drawn, [int(cv2.IMWRITE_JPEG_QUALITY), 80])
    drawn = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    box = (101.0, 42.0, 179.0, 218.0)  # 다시 추론한 박스는 몇 px 어긋난다
    assert xiao_hardcases.overlay_fraction(drawn, box) > 0.9
    assert xiao_hardcases.overlay_fraction(clean, box) < 0.2


def test_merge_coco_renumbers_and_checks_categories():
    base = rf100_prepare.empty_coco("train", "v0")
    rf100_prepare.add_image(base, "a.jpg", 10, 20, [("helmet", (1, 1, 5, 5))])
    extra = rf100_prepare.empty_coco("train", "xiao")
    rf100_prepare.add_image(
        extra, "x.jpg", 10, 20, [("vest", (1, 1, 5, 5)), ("helmet", (2, 2, 4, 4))]
    )
    merged = xiao_hardcases.merge_coco(base, [extra])
    assert [i["id"] for i in merged["images"]] == [1, 2]
    assert [a["id"] for a in merged["annotations"]] == [1, 2, 3]
    assert [a["image_id"] for a in merged["annotations"]] == [1, 2, 2]
    bad = {**extra, "categories": extra["categories"][:2]}
    with pytest.raises(SystemExit):
        xiao_hardcases.merge_coco(base, [bad])


# ── export_ppe ──────────────────────────────────────────────
def test_expected_output_shape_is_raw_4class_yolox():
    assert export_ppe.expected_output_shape(4) == [1, 8400, 9]


def test_load_frame_prefers_raw_over_drawn(tmp_path):
    """`--save-raw-dir <세션>/raw` 원본이 있으면 판정을 그린 `frames/` 대신 그것을 읽는다."""
    import cv2

    (tmp_path / "frames").mkdir()
    (tmp_path / "raw").mkdir()
    cv2.imwrite(str(tmp_path / "frames" / "00001.jpg"), np.full((8, 8, 3), 255, np.uint8))
    assert xiao_hardcases.load_frame(tmp_path, "00001").min() > 200
    cv2.imwrite(str(tmp_path / "raw" / "00001.jpg"), np.zeros((8, 8, 3), np.uint8))
    assert xiao_hardcases.load_frame(tmp_path, "00001").max() < 30


def test_exp_falls_back_to_standard_cocoeval():
    """학습 중 평가가 C++ 즉석 빌드(`where cl`)에 막히지 않게 표준 COCOeval 을 쓴다."""
    pytest.importorskip("yolox")  # 학습 환경(C:\dev\ppe-train\.venv)에서만 돈다
    import importlib.util

    import yolox.layers
    from pycocotools.cocoeval import COCOeval

    path = Path(__file__).resolve().parents[1] / "tools" / "ppe" / "yolox_exp_ppe_s.py"
    spec = importlib.util.spec_from_file_location("yolox_exp_ppe_s", path)
    spec.loader.exec_module(importlib.util.module_from_spec(spec))
    assert yolox.layers.COCOeval_opt is COCOeval


# ── mendeley_prepare ─────────────────────────────────────────────────
from tools.ppe import mendeley_prepare  # noqa: E402


def test_mendeley_names_map_and_stop_on_unknown(tmp_path):
    yaml = tmp_path / "data.yaml"
    yaml.write_text("nc: 4\nnames: ['Helmet', 'NoHelmet', 'NoVest', 'Vest']\n", encoding="utf-8")
    names = mendeley_prepare.read_names(yaml)
    assert mendeley_prepare.map_names(names) == ["helmet", "no_helmet", "no_vest", "vest"]
    with pytest.raises(SystemExit):
        mendeley_prepare.map_names(["Helmet", "Gloves"])


def test_mendeley_read_yolo_converts_normalized_center_boxes():
    names = ["helmet", "no_helmet", "no_vest", "vest"]
    out = mendeley_prepare.read_yolo("1 0.5 0.25 0.2 0.1\n\n3 0.5 0.5 0.4 0.4\n", names, 640, 640)
    assert out[0][0] == "no_helmet"
    assert out[0][1] == pytest.approx((256.0, 128.0, 384.0, 192.0))
    assert out[1][0] == "vest"
    with pytest.raises(SystemExit):
        mendeley_prepare.read_yolo("0 0.1 0.1 0.2 0.2 0.3 0.3\n", names, 640, 640)


def test_mendeley_dhash_matches_recompressed_resize_but_not_other_image():
    import cv2

    rng = np.random.default_rng(0)
    base = cv2.GaussianBlur(rng.integers(0, 255, (480, 640, 3), dtype=np.uint8), (31, 31), 0)
    resized = cv2.resize(base, (640, 640))
    ok, buf = cv2.imencode(".jpg", resized, [int(cv2.IMWRITE_JPEG_QUALITY), 70])
    assert ok
    recompressed = cv2.imdecode(buf, cv2.IMREAD_COLOR)
    other = cv2.GaussianBlur(rng.integers(0, 255, (480, 640, 3), dtype=np.uint8), (31, 31), 0)
    pool = [mendeley_prepare.hashes_with_flip(base)]
    assert mendeley_prepare.near_any(mendeley_prepare.dhash(recompressed), pool)
    assert not mendeley_prepare.near_any(mendeley_prepare.dhash(other), pool)


def test_mendeley_split_valid_is_seeded_and_halves():
    stems = [f"img{i:03d}" for i in range(10)]
    a = mendeley_prepare.split_valid(stems, 7)
    assert a == mendeley_prepare.split_valid(list(reversed(stems)), 7)
    assert sorted(a.values()).count("test") == 5
    assert set(a.values()) == {"test", "val"}


# ── pipeline_mock ────────────────────────────────────────────────────
from tools.ppe import pipeline_mock  # noqa: E402


def test_pipeline_mock_expected_state_from_body_part_labels():
    person = (0.0, 0.0, 100.0, 300.0)
    worn = [("helmet", (30.0, 0.0, 70.0, 40.0)), ("vest", (10.0, 100.0, 90.0, 200.0))]
    assert pipeline_mock.expected_state(person, worn) == pipeline_mock.STATE_OK
    bare = [("no_helmet", (30.0, 0.0, 70.0, 40.0)), ("vest", (10.0, 100.0, 90.0, 200.0))]
    assert pipeline_mock.expected_state(person, bare) == pipeline_mock.STATE_VIOLATION
    # 몸통 라벨이 없으면 정답을 모른다
    assert pipeline_mock.expected_state(person, worn[:1]) is None
    # 다른 사람의 조끼(이 사람 몸통 구간 밖)는 이 사람의 정답이 아니다
    other = [("helmet", (30.0, 0.0, 70.0, 40.0)), ("no_vest", (300.0, 100.0, 380.0, 200.0))]
    assert pipeline_mock.expected_state(person, other) is None


def test_pipeline_mock_summarize_counts_false_violation_and_unknown():
    ok, bad, unk = (
        pipeline_mock.STATE_OK,
        pipeline_mock.STATE_VIOLATION,
        pipeline_mock.STATE_UNKNOWN,
    )
    s = pipeline_mock.summarize(
        [
            (ok, ok, ""),
            (ok, bad, ""),
            (ok, unk, "머리 미검출"),
            (bad, bad, ""),
            (bad, unk, "머리 미검출"),
        ]
    )
    assert s["persons"] == 5
    assert s["compliant_false_violation"] == 1
    assert s["compliant_false_violation_pct"] == pytest.approx(33.3)
    assert s["violation_recall_pct"] == pytest.approx(50.0)
    assert s["undetermined_pct"] == pytest.approx(40.0)
    assert s["undetermined_reasons"] == {"머리 미검출": 2}
    assert s["effective_accuracy_pct"] == pytest.approx(40.0)


def test_mendeley_near_catches_horizontally_flipped_copy():
    import cv2

    rng = np.random.default_rng(3)
    base = cv2.GaussianBlur(rng.integers(0, 255, (480, 640, 3), dtype=np.uint8), (31, 31), 0)
    pool = [mendeley_prepare.hashes_with_flip(base)]
    flipped = cv2.flip(base, 1)
    assert mendeley_prepare.near_any(mendeley_prepare.dhash(flipped), pool)


def test_mendeley_read_names_refuses_empty_or_block_list(tmp_path):
    yaml = tmp_path / "data.yaml"
    yaml.write_text("nc: 2\nnames:\n  - Helmet\n  - Vest\n", encoding="utf-8")
    with pytest.raises(SystemExit):
        mendeley_prepare.read_names(yaml)


def test_mendeley_requires_contiguous_base_ids():
    good = {"images": [{"id": 1}, {"id": 2}], "annotations": [{"id": 1}, {"id": 2}]}
    mendeley_prepare.check_contiguous(good, "base")
    bad = {"images": [{"id": 1}, {"id": 3}], "annotations": [{"id": 1}]}
    with pytest.raises(SystemExit):
        mendeley_prepare.check_contiguous(bad, "base")


def test_mendeley_refuses_duplicate_basenames(tmp_path):
    a, b = tmp_path / "train" / "x.jpg", tmp_path / "valid" / "x.jpg"
    with pytest.raises(SystemExit):
        mendeley_prepare.check_unique_names([a, b])


# ── mendeley_prepare.prepare · pipeline_mock.main 끝까지 ─────────────
def _yolo_line(cls: int, box: tuple[float, float, float, float], w: int = 100, h: int = 200) -> str:
    x1, y1, x2, y2 = box
    return f"{cls} {(x1 + x2) / 2 / w} {(y1 + y2) / 2 / h} {(x2 - x1) / w} {(y2 - y1) / h}"


def _fake_mendeley(root: Path, rf_raw: Path) -> Path:
    import shutil

    md_root = root / "md"
    md_root.mkdir()
    (md_root / "data.yaml").write_text(
        "nc: 4\nnames: ['Helmet', 'NoHelmet', 'NoVest', 'Vest']\n", encoding="utf-8"
    )
    worn = "\n".join([_yolo_line(0, HELMET), _yolo_line(3, VEST)])
    bare = "\n".join([_yolo_line(1, HELMET), _yolo_line(3, VEST)])
    for split, name, seed, text in [
        ("train", "m1", 10, worn),
        ("train", "m2", None, worn),  # Roboflow test 사진과 같은 사진 → 빠진다
        ("valid", "va", 11, bare),
        ("valid", "vb", 12, worn),
    ]:
        image = md_root / split / "images" / f"{name}.jpg"
        if seed is None:
            image.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy(rf_raw / "test" / "t1.jpg", image)
        else:
            _write_image(image, seed)
        label = md_root / split / "labels" / f"{name}.txt"
        label.parent.mkdir(parents=True, exist_ok=True)
        label.write_text(text + "\n", encoding="utf-8")
    return md_root


def _fake_people(paths, *_args):
    return {"key": {"model_sha256": "fake"}, "boxes": {p.name: [list(PERSON)] for p in paths}}


def test_mendeley_prepare_merges_dedupes_and_keeps_roboflow_test(tmp_path, monkeypatch):
    rf_raw = _fake_raw(tmp_path)
    base = tmp_path / "build" / "v0"
    rf100_prepare.prepare(rf_raw, base, "v0", seed=1)
    md_raw = _fake_mendeley(tmp_path, rf_raw)
    monkeypatch.setattr(mendeley_prepare, "detect_people", _fake_people)
    out = tmp_path / "build" / "v1"

    card = mendeley_prepare.prepare(
        md_raw, rf_raw, base, out, "v1", device="x", coco_model=tmp_path / "coco.onnx", seed=1
    )

    stats = card["mendeley_stats"]
    assert stats["train"]["excluded_images"] == {mendeley_prepare.REASON_NEAR_DUP_RF: 1}
    assert stats["train"]["merged_images"] == 2  # Roboflow 1 + Mendeley 1
    assert stats["val"]["merged_images"] + stats["test"]["merged_images"] == 1 + 2
    # Roboflow test 주석은 바이트 그대로다 — v1 과 같은 잣대
    same = "instances_test.json"
    assert (out / "annotations" / same).read_bytes() == (base / "annotations" / same).read_bytes()
    md_test = json.loads((out / "annotations" / mendeley_prepare.MD_TEST_ANN).read_text("utf-8"))
    assert all(im["file_name"].startswith("md_") for im in md_test["images"])
    for split, folder in (("train", "train2017"), ("val", "val2017")):
        coco = json.loads((out / "annotations" / f"instances_{split}.json").read_text("utf-8"))
        mendeley_prepare.check_contiguous(coco, split)
        for im in coco["images"]:
            assert (out / folder / im["file_name"]).is_file()
    assert json.loads((out / "data_card.json").read_text("utf-8"))["dataset_version"] == "v1"
    with pytest.raises(SystemExit, match="출력 폴더가 이미 있다"):  # 같은 출력에 다시 쓰지 않는다
        mendeley_prepare.prepare(
            md_raw, rf_raw, base, out, "v1", device="x", coco_model=tmp_path / "c", seed=1
        )

    # 이어서 목업 평가기를 끝까지 — 검출기만 가짜로 바꾼다
    from tools.ppe import ppe_live_check

    class FakeDetector:
        def __init__(self, *args, **kwargs):
            pass

    def fake_process(*_args, **_kwargs):
        person = Detection("person", 0.9, PERSON)
        return [(person, ppe_live_check.Judgement(pipeline_mock.STATE_OK, "", ()), (0, 0))]

    import host.vision.detector as detector_module

    monkeypatch.setattr(detector_module, "Detector", FakeDetector)
    monkeypatch.setattr(pipeline_mock, "process", fake_process)
    result_path = tmp_path / "mock.json"
    assert (
        pipeline_mock.main(
            [
                "--rf-raw", str(rf_raw),
                "--md-raw", str(md_raw),
                "--build", str(out),
                "--coco-model", str(tmp_path / "coco.onnx"),
                "--model", f"m={tmp_path / 'm.onnx'}",
                "--out", str(result_path),
            ]
        )
        == 0
    )  # fmt: skip
    result = json.loads(result_path.read_text("utf-8"))
    rf = result["models"]["m"]["roboflow_test"]
    assert rf["persons"] == 1 and rf["confusion"]["적합"] == {"적합": 1}
    assert result["images"]["mendeley_test"] == stats["test"]["merged_images"]


def test_mendeley_detect_people_keeps_person_boxes_and_reuses_cache(tmp_path, monkeypatch):
    import host.vision.detector as detector_module

    calls = []

    class FakeDetector:
        def __init__(self, config, **_kwargs):
            calls.append(config["vision"]["coco"]["model_path"])

        def detect(self, _image):
            return [Detection("person", 0.9, PERSON), Detection("chair", 0.8, VEST)]

    monkeypatch.setattr(detector_module, "Detector", FakeDetector)
    model = tmp_path / "coco.onnx"
    model.write_bytes(b"weights")
    image = tmp_path / "a.jpg"
    _write_image(image, 5)
    cache = tmp_path / "cache.json"

    first = mendeley_prepare.detect_people([image], cache, "mechdog-01", model)
    assert first["boxes"] == {"a.jpg": [list(PERSON)]}
    assert first["key"]["model_sha256"] == mendeley_prepare.sha256_file(model)
    assert calls == [str(model)]
    again = mendeley_prepare.detect_people([image], cache, "mechdog-01", model)
    assert again == first and len(calls) == 1  # 같은 검출기면 캐시를 쓴다
    model.write_bytes(b"other weights")
    mendeley_prepare.detect_people([image], cache, "mechdog-01", model)
    assert len(calls) == 2  # 가중치가 바뀌면 다시 돌린다


def test_mendeley_main_refuses_output_outside_datasets_and_passes_arguments(tmp_path, monkeypatch):
    seen = {}

    def fake_prepare(_md_raw, _rf_raw, _base, out, version, **kwargs):
        seen.update(out=out, version=version, **kwargs)
        return {"mendeley_stats": {}}

    monkeypatch.setattr(mendeley_prepare, "prepare", fake_prepare)
    common = ["--md-raw", "m", "--rf-raw", "r", "--base", "b", "--coco-model", "c.onnx"]
    with pytest.raises(SystemExit, match="datasets/ 아래"):
        mendeley_prepare.main([*common, "--out", str(tmp_path / "x"), "--version", "v"])
    inside = mendeley_prepare.ROOT / "datasets" / "ppe" / "build" / "never_written"
    assert mendeley_prepare.main([*common, "--out", str(inside), "--version", "v9"]) == 0
    assert seen["version"] == "v9" and seen["device"] == "mechdog-01" and seen["seed"] == 20260928
    assert not inside.exists()


def test_export_ppe_verify_records_host_check_and_refuses_hash_mismatch(tmp_path, monkeypatch):
    import host.vision.detector as detector_module

    class FakeDetector:
        def __init__(self, config, **_kwargs):
            self.path = config["vision"]["ppe"]["model_path"]

        def detect(self, _image):
            return [Detection("helmet", 0.9, HELMET)]

    monkeypatch.setattr(detector_module, "Detector", FakeDetector)
    onnx = tmp_path / "ppe.onnx"
    onnx.write_bytes(b"onnx bytes")
    meta = {"sha256": export_ppe.sha256_file(onnx), "classes": list(rf100_prepare.CLASSES)}
    export_ppe.metadata_path(onnx).write_text(json.dumps(meta), encoding="utf-8")
    images = tmp_path / "val2017"
    for i in range(5):
        _write_image(images / f"{i}.jpg", i)
    # 이름순 맨 앞 — 확장자 필터가 없으면 이 파일이 골라져 images 가 3이 안 된다
    (images / "0_notes.txt").write_text("not an image", encoding="utf-8")

    args = ["verify", "--device", "mechdog-01", "--onnx", str(onnx), "--images", str(images)]
    assert export_ppe.main([*args, "--count", "3"]) == 0
    check = json.loads(export_ppe.metadata_path(onnx).read_text("utf-8"))["host_check"]
    assert check["images"] == 3 and check["with_boxes"] == 3
    assert check["results"][0]["labels"] == ["helmet"]

    onnx.write_bytes(b"changed")
    with pytest.raises(SystemExit, match="sha256"):
        export_ppe.main(args)


def test_export_ppe_small_helpers(tmp_path):
    assert export_ppe.pick_evenly([Path(str(i)) for i in range(10)], 3) == [
        Path("0"),
        Path("3"),
        Path("6"),
    ]
    assert export_ppe.pick_evenly([Path("a")], 3) == [Path("a")]
    missing = tmp_path / "none.pth"
    assert export_ppe.file_ref(None) is None
    assert export_ppe.file_ref(missing)["missing"] is True
    present = tmp_path / "w.pth"
    present.write_bytes(b"w")
    assert export_ppe.file_ref(present)["sha256"] == export_ppe.sha256_file(present)
    assert export_ppe.iso_mtime(present)[:4].isdigit()
