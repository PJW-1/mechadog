"""가상 MechDog — 통신 상대방으로서의 로봇 (WBS 6.1.1).

명령 포트에서 듣고, 가짜 텔레메트리를 10Hz 로 돌려주고, 주문한 대로 고장난다.
호스트 코드 입장에서는 네트워크 저쪽에 진짜 로봇이 있는 것과 구분되지 않는다.

**물리 시뮬레이터가 아니다.** 보행을 계산하지도, 공간을 그리지도 않는다.
흉내 내는 것은 *프로토콜 참여자로서의 로봇*뿐이다 — 명령을 받고, 상태를
보고하고, 가끔 고장나는 역할. 실제로 걷는지는 G1 실기 검수(6.4.1)에서 본다.

왜 필요한가:

  ① **CI 러너에는 로봇이 없다.** 로봇을 몇 대 갖고 있든 GitHub Actions 는
     우분투 컨테이너다. 목업이 없으면 통신 계층은 CI 에서 영원히 검증되지 않는다.
  ② **안전 시나리오를 실물로 반복 재현하기 어렵다.** 전도 시험은 로봇을 일부러
     넘어뜨려야 하고 서보 기어가 상한다. 저전압은 방전에 수십 분이 걸린다.
     여기서는 플래그 하나이고, `--seed` 로 같은 고장을 몇 번이든 재현한다.

⚠️ **이 파일은 온보드 안전 로직의 구현이 아니다.** Tier 1 은 펌웨어(WBS 3.2,
L1·L2)에 있고 여기 있는 것은 그 *대역*이다. 임계값을 `config.yaml` 에서 읽는
이유도 그래서다 — 목업이 자체 숫자를 갖게 되면 호스트를 진짜와 다른 기준으로
시험하게 된다.

펌웨어처럼 래치된 채 부팅하고, 명령 타임아웃(`safety.cmd_timeout_ms`)이 지나면
곧바로 래치한다. 어느 쪽이든 `RESET_SAFE` 로만 푼다 (ADR-39).

`RESET_SAFE` 수락 규칙은 펌웨어를 따른다 (`firmware/mechdog_motion/src/safety_monitor.h`
`reset_safe_allowed` = `!battery_critical()`):

  · 전압이 `safety.battery_shutdown_v` 이하로 내려가면 **저전압 원인**이 걸리고 래치한다.
  · 원인은 전압이 `safety.battery_warn_v` **위로** 회복될 때까지 남는다
    (`safety_monitor.cpp` 의 히스테리시스). 그 사이(6.6~7.0V)의 `RESET_SAFE` 는 거부한다.
  · 펌웨어는 셧다운을 연속 3표본(`shutdown_samples`)으로 판정하고 전압은 9표본 중앙값이다.
    목업의 전압은 잡음 없는 곡선이라 둘 다 결과를 바꾸지 않으므로 흉내 내지 않는다.
  · 펌웨어는 Wi-Fi 미연결·OTA 검증 대기 중에도 `RESET_SAFE` 를 거부한다
    (`mechdog_motion.ino` `CmdType::ResetSafe`). 목업에는 둘 다 없는 개념이다.
  · 전도(`--tip-at`)는 펌웨어에 아직 없다 (감지가 Phase 2 로 이연, `NFR-2.4`). 목업은
    `safety_monitor.h` 가 예고한 대로 «전도 중에는 해제 거부» 를 미리 흉내 낸다 — 풀어 주면
    `tipped:true` 인 채 `FAILSAFE` 가 아닌 상태를 보고해 호스트 규칙 ⑤에 폐기된다.

사용:

    python tools/mock/mock_mechdog.py --device mechdog-ref
    python tools/mock/mock_mechdog.py --tip-at 30 --drop-rate 0.2 --seed 42
"""

import argparse
import contextlib
import math
import random
import socket
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

# `python tools/mock/mock_mechdog.py` 로 직접 실행해도 host/ 를 찾게 한다.
# (pytest 는 pyproject 의 pythonpath 설정으로 해결된다)
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))

from host.common.config import load_base_config  # noqa: E402
from host.common.console import survive_encoding_errors  # noqa: E402
from host.common.protocol import (  # noqa: E402
    BATT_MAX_V,
    BATT_MIN_V,
    CommandDecoder,
    DecodeResult,
    TelemetryEncoder,
    system_clock_ms,
)

ROOT = Path(__file__).resolve().parents[2]
CONFIG = ROOT / "config" / "config.yaml"


def load_config(path: Path = CONFIG) -> dict:
    """목업은 개체 캘리브레이션이 필요 없으므로 검증된 전역 설정만 읽는다."""
    return load_base_config(path)


# ══════════════════════════════════════════════════════════════
#  장애 주입
# ══════════════════════════════════════════════════════════════


@dataclass
class Faults:
    """주문 가능한 고장. 전부 끄면 정상 동작하는 로봇이 된다.

    시각 기준 옵션(`*_at_s`)은 **기동 후 경과 초**다.
    """

    drop_rate: float = 0.0  # 수신 명령 유실률 (0.0~1.0)
    corrupt_rate: float = 0.0  # 깨진 텔레메트리 송신률 — 호스트 규칙 ③ 시험용
    battery_start_v: float | None = None  # 기본은 만충
    battery_drain_v_per_min: float = 0.0  # 방전 속도
    tip_at_s: float | None = None  # 이 시각에 전도
    obstacle_at_s: float | None = None  # 이 시각에 장애물 출현 (초음파 반사)
    go_silent_at_s: float | None = None  # 이 시각부터 텔레메트리 중단 (링크 두절)
    seed: int | None = None  # 같은 고장을 재현하기 위한 난수 씨앗


@dataclass
class Stats:
    received: int = 0
    accepted: int = 0
    clamped: int = 0
    discarded: int = 0
    dropped: int = 0  # 장애 주입으로 버린 것 (수신조차 안 한 셈)
    sent: int = 0

    def summary(self) -> str:
        return (
            f"수신 {self.received} · 수락 {self.accepted} · 클램핑 {self.clamped} · "
            f"폐기 {self.discarded} · 유실 {self.dropped} · 송신 {self.sent}"
        )


# ══════════════════════════════════════════════════════════════
#  로봇 — 순수 로직 (소켓을 모른다)
# ══════════════════════════════════════════════════════════════


@dataclass
class _LastCommand:
    """마지막으로 받아들인 명령. 텔레메트리의 근거가 된다."""

    at_ms: int = 0
    type: str = ""
    step: float = 0.0
    angle: float = 0.0
    pitch: float = 0.0
    #: 호스트가 `STATE` 로 알려준 FSM 상태. 로봇은 판단에 쓰지 않고 되돌려준다.
    host_state: str = ""


class MockRobot:
    """통신 상대방으로서의 로봇.

    시각을 인자로 받는다 (ENGINEERING_GUIDE 2.1). 그래서 30초 뒤의 전도도,
    10분간의 방전도 pytest 안에서 즉시 검증된다 — 소켓도 대기도 없이.
    """

    def __init__(
        self,
        device_id: str,
        cfg: dict,
        faults: Faults | None = None,
        start_ms: int = 0,
    ) -> None:
        self._cfg = cfg
        self._safety = cfg["safety"]
        self._faults = faults or Faults()
        self._rng = random.Random(self._faults.seed)
        self._start_ms = start_ms
        self._decoder = CommandDecoder()
        self._encoder = TelemetryEncoder(
            device_id, f"mock-{start_ms:016x}", clock=lambda: self._now_ms
        )
        self._now_ms = start_ms
        self._last = _LastCommand(at_ms=start_ms)
        self._link_seen = False  # 한 번이라도 유효 명령을 받았는가
        # 펌웨어처럼 **래치된 채 부팅한다** (`motion_safety_state.h` 의 `safe_latched = true`).
        # 받아들인 `RESET_SAFE` 전까지 MOVE·POSE 는 적용되지 않는다 — 가짜가 실물보다
        # 친절하면 호스트가 실기에서만 막히는 길을 목업에서 놓친다.
        self._failsafe_latched = True
        # 펌웨어 `SafetyMonitor::battery_critical()` — 셧다운선에서 걸고 경고선 위에서 푼다.
        self._battery_critical = False
        # 후진하면 장애물이 멀어진다. ⚠️ **거친 모형이다** — 목적은 정확한 거리가
        # 아니라 *"물러나면 언젠가 풀린다"* 는 단조 관계뿐이다. 그것이 없으면 호스트의
        # 회피 시퀀스가 끝까지 도는지 확인할 수 없다. 실제 해제 판정은 로봇의 센서가
        # 하고, 여기서는 보폭(mm)을 초당 이동량으로 간주한다 (대략 1초에 한 걸음).
        self._retreat_mm = 0.0
        self._motion_at_ms = start_ms
        self.stats = Stats()

    # ── 수신 ────────────────────────────────────────────────

    def receive(self, raw: str | bytes, now_ms: int) -> DecodeResult | None:
        """명령 한 건을 처리한다. `None` 은 장애 주입으로 유실시켰다는 뜻이다.

        유실은 파싱 실패와 다르다 — 패킷이 도착조차 하지 않은 것이므로
        수신 통계에도 잡히지 않는다. UDP 에서 실제로 일어나는 일이다.
        """
        self._now_ms = now_ms
        # 복구 패킷으로 시각을 덮기 전에 단절을 판정한다.
        self._update_safety(now_ms)
        if self._rng.random() < self._faults.drop_rate:
            self.stats.dropped += 1
            return None

        self.stats.received += 1
        result = self._decoder.decode(raw)
        if not result.accepted:
            self.stats.discarded += 1
            return result

        self.stats.accepted += 1
        if result.clamped:
            self.stats.clamped += 1

        # 규칙 ③ — 받아들인 패킷만 링크 타임아웃을 갱신한다.
        msg = result.message
        self._link_seen = True
        # ⚠️ **명령마다 자기가 바꾸는 것만 바꾼다.** 나머지는 유지해야 한다.
        # 실물 로봇은 다음 지시가 올 때까지 현재 자세와 보행을 이어가며, 호스트는
        # 상태가 바뀔 때만 STATE 를, 자세를 바꿀 때만 POSE 를 보내고 MOVE 는
        # 10Hz 로 보낸다. 명령 하나가 다른 값을 0 으로 되돌리면 뒤따르는 MOVE
        # 한 건에 자세가 사라져, 자세 상승 시퀀스(FR-9.2.2)를 시험할 수 없다.
        kind = msg["type"]
        prev = self._last
        if kind == "ESTOP":
            self._failsafe_latched = True
        reset = kind == "RESET_SAFE" and not self._physical_fault(now_ms)
        if reset:
            self._failsafe_latched = False
        moving = kind == "MOVE" and not self._failsafe_latched
        stop = kind in {"STOP", "ESTOP", "RESET_SAFE"} or self._failsafe_latched
        self._last = _LastCommand(
            at_ms=now_ms,
            type=kind,
            # STOP 은 move(0,0) 이므로 보행만 멈춘다. 자세는 그대로다.
            step=msg["step"] if moving else (0.0 if stop else prev.step),
            angle=msg["angle"] if moving else (0.0 if stop else prev.angle),
            pitch=msg["pitch"] if kind == "POSE" and not self._failsafe_latched else prev.pitch,
            host_state="IDLE" if reset else (msg["state"] if kind == "STATE" else prev.host_state),
        )
        return result

    # ── 로봇이 스스로 아는 것들 ────────────────────────────

    def _elapsed_s(self, now_ms: int) -> float:
        return (now_ms - self._start_ms) / 1000.0

    def _fault_active(self, at_s: float | None, now_ms: int) -> bool:
        return at_s is not None and self._elapsed_s(now_ms) >= at_s

    def battery_v(self, now_ms: int) -> float:
        """방전 곡선. 물리 하한에서 멈춘다.

        6.0V 아래로 내려가면 호스트가 규칙 ④로 **레코드 자체를 폐기**하므로,
        정작 보여주려던 셧다운 동작이 화면에 나타나지 않는다. 하한에서 붙든다.
        """
        start = self._faults.battery_start_v
        if start is None:
            start = BATT_MAX_V  # 만충
        drained = start - self._faults.battery_drain_v_per_min * (self._elapsed_s(now_ms) / 60.0)
        return round(max(BATT_MIN_V, drained), 2)

    def distance_cm(self, now_ms: int) -> int:
        """초음파. 장애물 주입 전에는 복도를 걷는 정도의 값을 흔들어 준다.

        장애물이 있으면 **후진한 만큼 멀어진다** — 위 `_retreat_mm` 설명 참고.
        """
        if self._fault_active(self._faults.obstacle_at_s, now_ms):
            base = max(0, self._safety["obstacle_stop_cm"] - 5)
            return int(base + self._retreat_mm / 10.0)
        return int(170 + 30 * math.sin(self._elapsed_s(now_ms)))

    def tipped(self, now_ms: int) -> bool:
        return self._fault_active(self._faults.tip_at_s, now_ms)

    def last_cmd_age_ms(self, now_ms: int) -> int:
        return max(0, now_ms - self._last.at_ms)

    def link_ok(self, now_ms: int) -> bool:
        if not self._link_seen:
            return False
        return self.last_cmd_age_ms(now_ms) <= self._safety["link_loss_failsafe_ms"]

    def command_timed_out(self, now_ms: int) -> bool:
        """마지막 유효 명령 뒤 `cmd_timeout_ms` 이상 조용했다 — 펌웨어는 여기서 래치한다."""
        return self._link_seen and self.last_cmd_age_ms(now_ms) >= self._safety["cmd_timeout_ms"]

    def _update_battery(self, now_ms: int) -> None:
        """펌웨어 `safety_monitor.cpp` 의 저전압 히스테리시스.

        ⚠️ **경고선 위로 올라와야 풀린다.** 셧다운선 바로 위에서 떠는 배터리로 풀면
        다음 보행 부하에 다시 걸려 사람이 해제와 재래치를 반복하게 된다.
        """
        volts = self.battery_v(now_ms)
        if volts <= self._safety["battery_shutdown_v"]:
            self._battery_critical = True
        elif volts > self._safety["battery_warn_v"]:
            self._battery_critical = False

    def _physical_fault(self, now_ms: int) -> bool:
        """래치를 걸고 `RESET_SAFE` 를 거부하는 원인. 호출 전에 `_update_battery` 가 돈다."""
        return self.tipped(now_ms) or self._battery_critical

    def _integrate_retreat(self, now_ms: int) -> None:
        """후진 중이면 물러난 거리를 누적한다. 전진은 되돌리지 않는다 —
        장애물이 다시 다가오는 것은 별개의 상황이고 주입으로 표현한다."""
        elapsed_s = max(0.0, (now_ms - self._motion_at_ms) / 1000.0)
        self._motion_at_ms = now_ms
        if self._last.step < 0:
            self._retreat_mm += abs(self._last.step) * elapsed_s

    def _update_safety(self, now_ms: int) -> None:
        self._integrate_retreat(now_ms)
        self._update_battery(now_ms)
        if self._physical_fault(now_ms) or self.command_timed_out(now_ms):
            self._failsafe_latched = True
        if self._failsafe_latched or not self._link_seen:
            self._last.step = self._last.angle = 0.0
            return
        # ⚠️ **근거리 반사 정지는 전진만 막는다** (FR-2.2 · FR-2.3).
        #
        # 전부 막으면 회피 시퀀스가 성립하지 않는다 — 정지 후 후진하라는 요구사항
        # 자체가 실행 불가가 된다. 초음파는 정면만 보므로 물러나는 것이 유일한 탈출
        # 경로이고, 후진 거리는 설정으로 제한된다.
        if self.distance_cm(now_ms) < self._safety["obstacle_stop_cm"] and self._last.step > 0:
            self._last.step = self._last.angle = 0.0

    def motion(self, now_ms: int) -> dict[str, float]:
        """실제 서보 대신 관측하는 보행 출력. 정지 시 과거 MOVE를 되살리지 않는다."""
        self._update_safety(now_ms)
        return {"step": self._last.step, "angle": self._last.angle}

    def state(self, now_ms: int) -> str:
        """**Tier 1 판정이 먼저, 그 다음이 호스트가 알려준 상태다.**

        FSM 은 Host PC 에서 돈다 (아키텍처 3절). 로봇이 스스로 내는 것은 셋뿐이고
        (`FAILSAFE`·`AVOID`, 그리고 해제 뒤의 `IDLE`), 나머지는 호스트가 `STATE` 명령으로
        알려준 것을 받아적어 되돌려준다.

        **순서가 규약이다** (아키텍처 1.2 불변 규칙) — 호스트가 `PATROL` 이라고 해도
        로봇이 전도를 감지했으면 `FAILSAFE` 를 보고한다. 온보드 안전 판정이 호스트의
        인식에 굴복하면 Tier 1 이 Tier 2 에 종속되어 이 구조의 의미가 사라진다.
        """
        # ── Tier 1 — 온보드 센서 판정. 호스트의 말보다 우선한다 ──
        self._update_safety(now_ms)
        # 링크 두절(`link_loss_failsafe_ms`)은 따로 볼 필요가 없다 — 설정 검증이
        # `cmd_timeout_ms < link_loss_failsafe_ms` 를 강제하므로 래치가 언제나 먼저 걸린다.
        if self._failsafe_latched:
            return "FAILSAFE"
        if self.distance_cm(now_ms) < self._safety["obstacle_stop_cm"]:
            return "AVOID"

        # ── Tier 2 — 호스트가 알려준 상태를 되돌려준다 ──
        # 래치가 풀렸다면 `RESET_SAFE` 가 이미 `IDLE` 을 적어 두었다(펌웨어도 해제 때
        # `g_reported_state = Idle`). 아래 기본값은 펌웨어의 초기값과 같게 둔 것뿐이다.
        return self._last.host_state or "IDLE"

    # ── 송신 ────────────────────────────────────────────────

    def telemetry(self, now_ms: int) -> str | None:
        """텔레메트리 한 줄. `None` 은 침묵 중이라는 뜻이다 (링크 두절 시험)."""
        self._now_ms = now_ms
        if self._fault_active(self._faults.go_silent_at_s, now_ms):
            return None

        self.stats.sent += 1
        if self._rng.random() < self._faults.corrupt_rate:
            # 호스트 규칙 ③ 시험 — 깨진 패킷이 타임아웃을 갱신하면 안 된다.
            return '{"seq": 무엇인가'

        tipped = self.tipped(now_ms)
        batt_v = self.battery_v(now_ms)
        return self._encoder.encode(
            state=self.state(now_ms),
            dist_cm=self.distance_cm(now_ms),
            imu=self._imu(now_ms, tipped=tipped),
            batt_v=batt_v,
            last_cmd_age_ms=self.last_cmd_age_ms(now_ms),
            flags={
                "lowbatt": batt_v <= self._safety["battery_warn_v"],
                "tipped": tipped,
                "link_ok": self.link_ok(now_ms),
                # 온보드 반사 정지가 지금 걸려 있는가. `state` 의 AVOID 로는 해제를
                # 알 수 없어서(호스트가 알려준 값이 되돌아온 것일 수 있다) 별도로
                # 보고한다 (ADR-22).
                "obstacle": self.distance_cm(now_ms) < self._safety["obstacle_stop_cm"],
            },
            motion=self.motion(now_ms),
            safety_latched=self._failsafe_latched,
        )

    def _imu(self, now_ms: int, *, tipped: bool) -> dict[str, float]:
        if tipped:
            # 전도 임계를 확실히 넘긴 값. 의도된 앉기 자세와 구분된다 (DR-16).
            return {"pitch": self._safety["tip_angle_deg"] + 15.0, "roll": 8.0, "yaw": 12.5}
        yaw = (self._last.angle * self._elapsed_s(now_ms)) % 360.0
        return {"pitch": round(self._last.pitch, 1), "roll": 0.2, "yaw": round(yaw, 1)}


# ══════════════════════════════════════════════════════════════
#  소켓 셸 — 위의 순수 로직을 UDP 에 연결한다
# ══════════════════════════════════════════════════════════════


@dataclass
class _LogState:
    """엣지 트리거 로깅용. 값이 **변할 때만** 찍는다 (ENGINEERING_GUIDE 1.3).

    10Hz × 10분이면 6,000줄이다. 매 명령을 찍으면 정작 중요한 전이가 묻힌다.
    """

    state: str = ""
    command: str = ""
    next_summary_ms: int = 0
    fields: dict = field(default_factory=dict)


def _describe(result: DecodeResult | None) -> str:
    if result is None:
        return "유실"
    msg = result.message or {}
    if not result.accepted:
        return f"폐기({result.reason})"
    body = " ".join(f"{k}={v}" for k, v in msg.items() if k not in ("seq", "ts", "type"))
    tail = f" ⟨클램핑 {','.join(result.clamped)}⟩" if result.clamped else ""
    return f"{msg.get('type')} {body}{tail}".strip()


def _log(now_ms: int, message: str) -> None:
    print(f"[{now_ms % 1_000_000:6d}] {message}", flush=True)


def run(robot: MockRobot, cfg: dict, peer_host: str | None = None, bind_host: str = "") -> None:
    """UDP 루프. 여기만 소켓과 실시간을 만진다."""
    net = cfg["network"]
    period_s = 1.0 / net["telemetry_rate_hz"]

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    # SO_REUSEADDR 를 쓰지 않는다 — Windows 에서 UDP 는 같은 포트에 조용히 이중
    # 바인드돼 명령을 하나도 못 받는다. 점유 중이면 bind 가 즉시 실패해야 한다.
    # 여러 대를 한 PC 에서 흉내 낼 때는 루프백 주소를 나눠 묶는다 (127.0.0.2 …).
    sock.bind((bind_host, net["cmd_port"]))
    sock.setblocking(False)

    # ⚠️ Windows 전용 — 아직 아무도 듣지 않는 포트로 텔레메트리를 보내면 ICMP
    # Port Unreachable 이 돌아오고, Windows 는 그것을 **다음 recvfrom 의
    # ConnectionResetError 로** 돌려준다. `SIO_UDP_CONNRESET` 은 CPython 에 없어
    # ioctl 로 끌 수 없으므로 아래 수신 루프가 그 예외를 잡아 넘긴다.

    log = _LogState()
    peer: tuple[str, int] | None = (peer_host, net["telemetry_port"]) if peer_host else None
    next_tx = time.monotonic()

    _log(system_clock_ms(), f"수신 대기 :{net['cmd_port']} · 텔레메트리 :{net['telemetry_port']}")
    while True:
        now_ms = system_clock_ms()

        while True:  # 도착한 것을 전부 비운다
            try:
                data, addr = sock.recvfrom(2048)
            except BlockingIOError:
                break
            except ConnectionResetError:
                # Windows 의 헛된 ICMP 통보 — 로봇 대역이 호스트 사정 때문에
                # 죽으면 안 된다.
                continue
            if peer is None:
                peer = (addr[0], net["telemetry_port"])
                _log(now_ms, f"호스트 발견 {peer[0]}")
            result = robot.receive(data, now_ms)
            described = _describe(result)
            if described != log.command:  # 엣지 트리거
                _log(now_ms, f"◀ {described}")
                log.command = described

        state = robot.state(now_ms)
        if state != log.state:
            _log(now_ms, f"■ 상태 {log.state or '(기동)'} → {state}")
            log.state = state

        if time.monotonic() >= next_tx:
            line = robot.telemetry(now_ms)
            if line is not None and peer is not None:
                # 호스트가 내려가 있어도 목업은 계속 보낸다 — 진짜 로봇도 그렇다.
                with contextlib.suppress(OSError):
                    sock.sendto(line.encode("utf-8"), peer)
            next_tx += period_s

        if now_ms >= log.next_summary_ms:  # 주기 요약
            if log.next_summary_ms:
                _log(now_ms, f"… {robot.stats.summary()} · batt {robot.battery_v(now_ms)}V")
            log.next_summary_ms = now_ms + 1000

        time.sleep(0.002)


# ══════════════════════════════════════════════════════════════
#  CLI
# ══════════════════════════════════════════════════════════════


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mock_mechdog",
        description="가상 MechDog — 통신 상대방으로서의 로봇 (WBS 6.1.1)",
    )
    parser.add_argument("--device", default="mechdog-mock", help="device_id (텔레메트리 필수 필드)")
    parser.add_argument("--host", default=None, help="텔레메트리 수신지. 기본은 첫 명령의 송신자")
    parser.add_argument(
        "--bind",
        default="",
        help="명령 포트를 묶을 주소. 여러 대면 127.0.0.2 처럼 나눈다 (기본 전체)",
    )

    faults = parser.add_argument_group("장애 주입")
    faults.add_argument("--drop-rate", type=float, default=0.0, help="수신 명령 유실률 0.0~1.0")
    faults.add_argument("--corrupt-rate", type=float, default=0.0, help="깨진 텔레메트리 송신률")
    faults.add_argument("--battery-start", type=float, default=None, help="시작 전압 V")
    faults.add_argument("--battery-drain", type=float, default=0.0, help="방전 속도 V/분")
    faults.add_argument("--tip-at", type=float, default=None, help="N초 후 전도")
    faults.add_argument("--obstacle-at", type=float, default=None, help="N초 후 장애물 출현")
    faults.add_argument("--go-silent", type=float, default=None, help="N초 후 텔레메트리 중단")
    faults.add_argument("--seed", type=int, default=None, help="같은 고장을 재현하기 위한 씨앗")
    return parser


def main(argv: list[str] | None = None) -> int:
    # ⚠️ **인자 처리보다 앞이다** — cp949 콘솔에서 `--help` 조차 죽었다
    # (CONTRIBUTING 8절). 도움말은 `argparse` 가 stdout 에 쓴다.
    survive_encoding_errors()
    args = build_parser().parse_args(argv)
    cfg = load_config()
    robot = MockRobot(
        device_id=args.device,
        cfg=cfg,
        faults=Faults(
            drop_rate=args.drop_rate,
            corrupt_rate=args.corrupt_rate,
            battery_start_v=args.battery_start,
            battery_drain_v_per_min=args.battery_drain,
            tip_at_s=args.tip_at,
            obstacle_at_s=args.obstacle_at,
            go_silent_at_s=args.go_silent,
            seed=args.seed,
        ),
        start_ms=system_clock_ms(),
    )
    with contextlib.suppress(KeyboardInterrupt):
        run(robot, cfg, peer_host=args.host, bind_host=args.bind)
    _log(system_clock_ms(), f"종료 · {robot.stats.summary()}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
