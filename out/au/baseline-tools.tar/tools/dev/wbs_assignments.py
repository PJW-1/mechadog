"""WBS 작업 사전에서 담당자별 작업 목록을 생성한다.

`docs/internal/WBS.md`의 작업 사전을 파싱해 **누가 무엇을 하는가**를
`docs/internal/ASSIGNMENTS.md`로 펼친다. 팀원은 생성된 파일에서 지금 시작할 수 있는 일만 본다.

**왜 손으로 쓰지 않는가** — 같은 숫자를 두 곳에 두면 반드시 어긋난다. 이 프로젝트에서
이미 여러 번 일어났다(총 공수 69.0 vs 70.0, 절 제목 5.5 vs 하위 합 6.5, 명령 7종 vs 8종).
그래서 **WBS 를 정본으로 두고 생성**하며, `tests/test_assignments.py` 가 커밋된 파일과
재생성 결과를 대조한다. WBS 를 고치고 재생성하지 않으면 CI 가 실패한다.

    python tools/dev/wbs_assignments.py            # 생성 (파일 갱신)
    python tools/dev/wbs_assignments.py --check    # 대조만 (CI·테스트용)
"""

import argparse
import re
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
WBS = ROOT / "docs" / "internal" / "WBS.md"
OUT = ROOT / "docs" / "internal" / "ASSIGNMENTS.md"

sys.path.insert(0, str(ROOT))

from host.common.console import survive_encoding_errors  # noqa: E402

#: WBS 작업 사전의 행 구조 — 8칸 고정.
#: `ID | 워크패키지 | 산출물 | 완료 기준(DoD) | R | 선행 | M/D | 연계`
_COLUMNS = 8
_ID, _NAME, _DELIV, _DOD, _R, _PRED, _MD = 0, 1, 2, 3, 4, 5, 6

#: 완료 표기 — `[완료]`와 `[완료 · PR #18]`처럼 근거가 붙은 형식을 모두 인식한다.
DONE_MARK = "[완료"

#: Phase 2 표기 — 워크패키지 이름 칸에 붙인다. DoD 안의 `[P2]` 는 항목 일부만 가리키므로 보지 않는다.
#: 2026-09-28 Phase 2 착수를 승인해 `[P2]` 항목도 할 일·남은 공수에 함께 센다(WBS `1.4`).
#: 표기는 남은 공수 중 Phase 2 몫을 따로 보이는 데만 쓴다.
PHASE2_MARK = "[P2]"

#: 담당자 배정 규칙 — 역할 범위는 docs/internal/TEAM_PROCESS.md 1절에 기록한다.
#: `R=A` 는 전부 L1·L2 이고, 여기에 `3.9`(구역 순찰)·`5.4`(ROS2 항법)가 이관된다.
#: 나머지 `B`·`C` 가 팀장 몫이다.
TRANSFERRED_TO_L: tuple[str, ...] = ("3.9", "5.4")

#: `R=A`(임베디드·하드웨어 성격)인데 **팀장이 직접 수행한** 워크패키지.
#:
#: 성격 분류(A/B/C)는 *"어떤 종류의 일인가"* 이고 사람이 아니다(docs/internal/TEAM_PROCESS.md 1절).
#: 착수 초기에 실기가 팀장 손에 있어서 하드웨어·펌웨어 항목 일부를 팀장이 직접
#: 처리했고, **그 사실을 담당별 목록에 반영하지 않으면 누가 무엇을 했는지 기록이
#: 사라진다.** 남은 공수에는 영향이 없다(전부 완료 항목이므로) — 바뀌는 것은
#: **완료 실적이 어느 쪽에 잡히는가** 뿐이다.
DONE_BY_S: tuple[str, ...] = ("2.1.0", "2.1.1", "4.1.1", "4.1.3", "5.1.2")

OWNERS: dict[str, str] = {
    "L1·L2": "펌웨어 · 하드웨어 · 온보드 안전로직 · 펌웨어 CI · 공간·항법",
    "S": "비전 · PPE · 변화감지 · 인증 · FSM · 통신 · config·로깅 · 대시보드 · 시험 · 문서",
}

#: 대분류 제목 — 소계 표에 쓴다.
GROUPS: dict[str, str] = {
    "1": "요구사항 및 범위 정의",
    "2": "장치 및 하드웨어",
    "3": "판단 로직 및 핵심 기능",
    "4": "소프트웨어 및 화면",
    "5": "통합 및 형상관리",
    "6": "시험 및 품질",
    "7": "보고 및 최종 제출",
}


@dataclass(frozen=True, slots=True)
class WorkPackage:
    wid: str
    name: str
    deliverable: str  # 무엇을 만들면 되는가 — 초보가 가장 먼저 찾는 정보
    role: str  # A · B · C (작업 성격)
    predecessor: str
    effort: float  # 0.0 = 공수 미산정(`—`)
    done: bool
    phase2: bool

    @property
    def group(self) -> str:
        return self.wid.split(".")[0]

    @property
    def owner(self) -> str:
        if self.wid in DONE_BY_S:  # 성격은 A 지만 팀장이 실제로 수행했다
            return "S"
        if any(self.wid.startswith(p) for p in TRANSFERRED_TO_L):
            return "L1·L2"
        return "L1·L2" if self.role == "A" else "S"

    def sort_key(self) -> tuple[int, ...]:
        return tuple(int(p) for p in self.wid.split("."))


def _clean(cell: str) -> str:
    return cell.replace("**", "").strip()


def parse_wbs(path: Path = WBS) -> list[WorkPackage]:
    """작업 사전에서 워크패키지를 뽑는다."""
    body = path.read_text(encoding="utf-8")
    start = body.index("## 작업 사전")

    packages: list[WorkPackage] = []
    for line in body[start:].splitlines():
        if not line.startswith("|"):
            continue
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if len(cells) != _COLUMNS:
            continue
        wid = _clean(cells[_ID])
        if not re.fullmatch(r"\d+(\.\d+)*", wid):
            continue
        effort = _clean(cells[_MD])
        if effort != "—" and not re.fullmatch(r"[\d.]+", effort):
            # 건너뛰면 그 일이 담당 목록에서 조용히 사라진다(`--check` 도 같이 빠져 못 잡는다).
            raise ValueError(f"{wid}: 공수 칸을 읽을 수 없다 — {effort!r} (숫자 또는 `—`)")
        packages.append(
            WorkPackage(
                wid=wid,
                name=_clean(cells[_NAME]),
                deliverable=_clean(cells[_DELIV]) or "—",
                role=_clean(cells[_R]),
                predecessor=_clean(cells[_PRED]) or "—",
                effort=0.0 if effort == "—" else float(effort),
                done=DONE_MARK in cells[_DOD],
                phase2=PHASE2_MARK in cells[_NAME],
            )
        )
    return sorted(packages, key=WorkPackage.sort_key)


def _dependency_ids(token: str, packages: list[WorkPackage]) -> set[str]:
    """선행 표기의 한 토큰을 실제 워크패키지 ID로 펼친다.

    `4.3.1` 같은 정확한 ID, `4.1` 같은 묶음, `3.2.1~4`와
    `2.1~2.4` 같은 범위를 지원한다. WBS 밖 조건(예: 장비 도착)은
    매칭되는 ID가 없으므로 완료 전까지 대기로 남는다.
    """
    token = token.strip()
    by_id = {p.wid for p in packages}
    if token in by_id:
        return {token}

    if "~" not in token:
        prefix = f"{token}."
        return {wid for wid in by_id if wid.startswith(prefix)}

    start_text, end_text = (part.strip() for part in token.split("~", 1))
    try:
        start = tuple(int(part) for part in start_text.split("."))
        if "." in end_text:
            end = tuple(int(part) for part in end_text.split("."))
        else:
            end = (*start[:-1], int(end_text))
    except ValueError:
        return set()
    if len(start) != len(end):
        return set()

    matched = set()
    for wid in by_id:
        parts = tuple(int(part) for part in wid.split("."))
        if len(parts) >= len(start) and start <= parts[: len(start)] <= end:
            matched.add(wid)
    return matched


def is_ready(package: WorkPackage, packages: list[WorkPackage]) -> bool:
    """선행 작업이 없거나, 명시된 선행 작업이 모두 완료됐는지 판정한다."""
    if package.predecessor == "—":
        return True

    by_id = {p.wid: p for p in packages}
    # ⚠️ 선행 표기는 쉼표와 가운뎃점을 섞어 쓴다 — `3.2.1·3.2.2·3.2.4, 3.2.6`.
    # 쉼표로만 나누면 그 덩어리가 어떤 ID 와도 맞지 않아 **선행이 전부 끝나도
    # 영원히 대기로 남는다**(2026-09-17 에 `3.2.5` 에서 드러났다). 가운뎃점을
    # 쓰지 않는 조건 표기(`LiDAR·마스트 도착`)는 나눠도 여전히 ID 가 없으므로
    # 대기로 남는다 — 의도한 동작이다.
    for token in package.predecessor.replace("·", ",").split(","):
        dependencies = _dependency_ids(token, packages)
        if not dependencies or not all(by_id[wid].done for wid in dependencies):
            return False
    return True


def _table(packages: list[WorkPackage], *, with_predecessor: bool) -> list[str]:
    head = (
        "| WBS | 할 일 | 만들 것 | 기다리는 것 | M/D |"
        if with_predecessor
        else ("| WBS | 할 일 | 만들 것 | M/D |")
    )
    rule = (
        "| :--- | :--- | :--- | :--- | ---: |"
        if with_predecessor
        else "| :--- | :--- | :--- | ---: |"
    )
    rows = []
    for p in packages:
        cells = [f"`{p.wid}`", p.name, p.deliverable]
        if with_predecessor:
            cells.append(p.predecessor)
        cells.append(f"{p.effort:.1f}" if p.effort else "—")
        rows.append("| " + " | ".join(cells) + " |")
    return [head, rule, *rows]


def render(packages: list[WorkPackage]) -> str:
    """담당자별 마크다운을 만든다.

    **정렬 기준은 대분류가 아니라 "지금 할 수 있는가" 다.** 처음 보는 사람이 묻는 것은
    *"내 일이 어느 대분류에 속하나"* 가 아니라 *"오늘 뭘 잡으면 되나"* 이기 때문이다.
    대분류 소계는 총량을 보기 위한 것이므로 뒤로 뺀다.
    """
    total = sum(p.effort for p in packages)
    lines: list[str] = [
        "# 내가 할 일",
        "",
        "> ⚠️ **이 파일은 생성된다. 직접 고치지 마라.**",
        "> 정본은 [WBS 작업 사전](WBS.md)이며, 여기는 그것을 담당자 기준으로 펼친 것이다.",
        ">",
        "> ```",
        "> python tools/dev/wbs_assignments.py",
        "> ```",
        ">",
        "> 작업 범위·선행·DoD·상태를 바꿨을 때만 WBS를 고치고 이 파일을 재생성한다.",
        "",
        "**읽는 법** — 자기 이름을 찾고 🟢 부터 잡는다. 선행 작업이 없거나 모두 끝난 것들이다.",
        "**끝났다고 말할 수 있는 조건(DoD)** 은 [WBS 작업 사전](WBS.md)에서 같은 번호를 찾으면 있다.",
        "",
        "| 담당 | ✅ 완료 | 🟢 지금 가능 | ⏳ 대기 | 남은 공수 | 그중 Phase 2 | 전체 |",
        "| :--- | ---: | ---: | ---: | ---: | ---: | ---: |",
    ]
    left = later = 0.0
    for owner in OWNERS:
        mine = [p for p in packages if p.owner == owner]
        done = [p for p in mine if p.done]
        todo = [p for p in mine if not p.done]
        phase2 = [p for p in todo if p.phase2]
        ready = [p for p in todo if is_ready(p, packages)]
        remaining = sum(p.effort for p in todo)
        left += remaining
        later += sum(p.effort for p in phase2)
        lines.append(
            f"| **{owner}** | {len(done)}건 | 🟢 {len(ready)}건 | "
            f"⏳ {len(todo) - len(ready)}건 | **{remaining:.1f}** M/D | "
            f"{len(phase2)}건 · {sum(p.effort for p in phase2):.1f} M/D | "
            f"{sum(p.effort for p in mine):.1f} M/D |"
        )
    lines += [
        f"| | | | | **{left:.1f}** M/D | {later:.1f} M/D | **{total:.1f}** M/D |",
        "",
        "> **남은 공수에는 Phase 2(`[P2]`) 몫이 들어 있다** — 2026-09-28 착수를 승인했다(WBS `1.4`). "
        "«그중 Phase 2» 열이 그 몫이다.",
        "",
        f"> **{', '.join('`' + w + '`' for w in DONE_BY_S)} 는 성격상 임베디드(`R=A`)지만 "
        "팀장이 직접 수행했다.** 그래서 완료 실적을 팀장 쪽에 잡는다 — 성격 분류는 "
        "사람이 아니다(docs/internal/TEAM_PROCESS.md 1절). 남은 공수에는 영향이 없다.",
        "",
        "---",
        "",
    ]

    for owner, scope in OWNERS.items():
        mine = [p for p in packages if p.owner == owner]
        done = [p for p in mine if p.done]
        todo = [p for p in mine if not p.done]
        phase2 = [p for p in todo if p.phase2]
        ready = [p for p in todo if is_ready(p, packages)]
        waiting = [p for p in todo if not is_ready(p, packages)]
        lines += [
            f"## {owner}",
            "",
            f"**담당 영역** — {scope}",
            "",
            f"**남은 공수 {sum(p.effort for p in todo):.1f} M/D · {len(todo)}건** "
            f"· 그중 Phase 2 {sum(p.effort for p in phase2):.1f} M/D · {len(phase2)}건 "
            f"(전체 {sum(p.effort for p in mine):.1f} M/D · {len(mine)}건)",
            "",
            f"### 🟢 지금 시작할 수 있다 — {len(ready)}건 · {sum(p.effort for p in ready):.1f} M/D",
            "",
            "선행 작업이 없거나 모두 완료됐다. 이 중 하나를 잡으면 된다.",
            "",
            *_table(ready, with_predecessor=False),
            "",
            f"### ⏳ 선행이 끝나야 시작한다 — {len(waiting)}건 · "
            f"{sum(p.effort for p in waiting):.1f} M/D",
            "",
            "**기다리는 것** 열의 번호가 끝나면 시작할 수 있다.",
            "",
            *_table(waiting, with_predecessor=True),
            "",
            f"<details><summary>✅ 완료 — {len(done)}건 · "
            f"{sum(p.effort for p in done):.1f} M/D</summary>",
            "",
            *_table(done, with_predecessor=False),
            "",
            "</details>",
            "",
            "<details><summary>대분류별 소계</summary>",
            "",
            "| 대분류 | 건수 | 공수 |",
            "| :--- | ---: | ---: |",
        ]
        for gid, gname in GROUPS.items():
            grouped = [p for p in mine if p.group == gid]
            if not grouped:
                continue
            lines.append(
                f"| **{gid}.0** {gname} | {len(grouped)}건 | {sum(p.effort for p in grouped):.1f} |"
            )
        lines += ["", "</details>", "", "---", ""]

    lines += [
        "> 할 일이 새로 생기거나 선행·상태가 바뀌면 WBS 작업 사전에 반영한 뒤 이 파일을 재생성한다.",
        "",
    ]
    return "\n".join(lines)


def main(argv: list[str] | None = None) -> int:
    # ⚠️ **인자 처리보다 앞이다** — cp949 콘솔에서 `--help` 조차 죽었다
    # (CONTRIBUTING 8절). 도움말은 `argparse` 가 stdout 에 쓴다.
    survive_encoding_errors()
    parser = argparse.ArgumentParser(prog="wbs_assignments", description="담당자별 작업 목록 생성")
    parser.add_argument("--check", action="store_true", help="쓰지 않고 커밋본과 대조만 한다")
    args = parser.parse_args(argv)

    rendered = render(parse_wbs())
    if not args.check:
        OUT.write_text(rendered, encoding="utf-8")
        print(f"{OUT.relative_to(ROOT)} 생성")
        return 0

    if not OUT.exists():
        print(
            f"{OUT.relative_to(ROOT)} 이 없다. `python tools/dev/wbs_assignments.py` 로 생성하라."
        )
        return 1
    if OUT.read_text(encoding="utf-8") != rendered:
        print(f"{OUT.relative_to(ROOT)} 가 WBS 와 어긋난다. 재생성하라.")
        return 1
    print("일치")
    return 0


if __name__ == "__main__":
    sys.exit(main())
