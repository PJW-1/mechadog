import {FactoryView,renderRobotPreviews} from './scene.js';
import {icon,renderIcons} from './icons.js';
import {Operations,ROBOTS} from './operations.js';
import {OperationalPanels} from './panels.js';
import {LiveMap} from './live-map.js';
import {Scene3D} from './scene3d.js';
import {registerPageTools} from './webmcp.js';
import {RobotDetailView} from './robot-view.js';
import {RobotLink} from './robot-link.js';
import {VoiceLink,resolveVoiceBase} from './voice-link.js';
import {VisionFeed} from './vision-feed.js';
import {EventFeed} from './event-feed.js';
import {TelemetryFeed,describeTelemetry} from './telemetry-feed.js';

renderIcons();
const $=id=>document.getElementById(id);
let view=null,robotView=null,toastTimer,currentPage='dashboard',lastOpener=null,observationFailed=false;
let visionFeed=null,visionStatus={state:'connecting'};
let panels=null;
let mainLiveMap=null,mapAvailable=false,scene3d=null;
// 서버가 실제 지도를 줬을 때만 예시 공장 자리를 실제 집 지도로 바꾼다. 없으면 «지도 없음» 을 그대로 말한다.
function showLiveMap(){const three=scene3d?.shown,shown=operations.live&&mapAvailable&&!three;$('live-house-map').hidden=!shown;$('map-placeholder').hidden=operations.demo||shown||three;$('scene-subtitle').textContent=three?'집 3D SIM · 드래그 회전, 휠 확대':operations.demo?'예시 공간 · 실제 위치 미수신':shown?'실제 집 지도 · 로봇이 추정한 위치':'지도 없음 · 예시 공장 숨김'}
// 로봇 시점 창의 문구는 **실제로 받고 있는 상태**를 말한다. 연결만 됐다고
// "실시간" 이라 하지 않는다 — 멈춘 장면이 실시간처럼 보이면 안 된다.
const VISION_TEXT={off:['영상 없음 · 비전 꺼짐','비전 채널 없음'],connecting:['영상 연결 중','연결 중'],waiting:['영상 대기 · 추론 결과 없음','연결됨 · 영상 대기'],live:['실시간 · 검출 박스','실시간 수신 중'],stale:['영상 멈춤 · 마지막 장면','새 영상 없음'],closed:['영상 끊김 · 다시 연결 중','연결 끊김 · 다시 연결 중']};
function syncVisionStatus(){
 $('app').classList.toggle('vision-has-frame',!!visionStatus.lastFrameAt);
 if(!operations.live)return;
 const [badge,status]=VISION_TEXT[visionStatus.state]||VISION_TEXT.connecting;
 $('frame-source').textContent=badge+(visionStatus.ppeTest?' · PPE 시험':'');
 $('camera-status').textContent=visionStatus.state==='live'?status+' · 검출 '+visionStatus.detections+'건 · 사람 '+visionStatus.persons+'명':status;
 $('camera-resolution').hidden=visionStatus.state!=='live';
 if(visionStatus.state==='live'){
  $('camera-resolution').textContent=visionStatus.width+' × '+visionStatus.height;
  // 칸이 영상 비율을 따라가야 옆여백이 안 생긴다 — 프레임 크기가 곧 정답이다.
  if(visionStatus.width>0&&visionStatus.height>0)document.documentElement.style.setProperty('--vision-aspect',visionStatus.width+' / '+visionStatus.height);
 }
 const at=visionStatus.lastFrameAt?new Date(visionStatus.lastFrameAt).toLocaleTimeString('ko-KR',{hour12:false}):'—';
 $('frame-time').innerHTML='마지막 영상 수신　'+at+' <span class="muted">· 관측 전용</span>';
 panels?.refreshGuardReadiness();
}
const cameraDock=$('camera-dock'),cameraHome=cameraDock.parentElement,cameraNext=cameraDock.nextElementSibling;
let storage=null;try{storage=localStorage}catch{/* Restricted browsers can still use session-only drafts. */}
// 실제 대시보드 연결은 **대시보드 서버가 이 페이지를 직접 내보냈을 때만** 붙는다
// (WBS 4.6.3). 그 밖에서 열면 링크가 없고 웹은 예시 모드 그대로다 — 공개된 화면이
// 저 혼자 로봇을 움직이게 두지 않는다.
// ⚠️ **다른 출처의 API 를 가리키는 길은 두지 않는다.** 예전의 `?api=`·`<meta>` 는
// 다른 포트를 받았지만, 서버의 출처 검사가 그 페이지의 명령(비상정지 포함)과 WS 를
// 전부 거절해 **연결된 척하고 아무것도 못 보내는 화면**이 됐다.
async function resolveApiBase(){
 try{
  // 대시보드 서버가 이 페이지를 직접 서빙하면 같은 출처가 곧 API 다.
  // 단, hostname 이 localhost 라는 것만으로는 붙지 않는다 — file:// 이나
  // 다른 로컬 개발 서버 위에서 열렸을 수 있으므로 /health 로 확인한다.
  if(!['127.0.0.1','localhost','[::1]'].includes(location.hostname))return null;
  const probe=await fetch('/health',{signal:globalThis.AbortSignal?.timeout?.(1500)}).catch(()=>null);
  if(!probe?.ok)return null;
  const info=await probe.json().catch(()=>null);
  return info?.service==='telemetry'?location.origin:null;
 }catch{return null}
}
const apiBase=await resolveApiBase();
// 여러 대(`host.fleet`)면 서버가 로봇 목록과 각자의 API 경로(`/robots/<id>`)를 알려 준다. 없으면 한 대짜리 서버다.
// ⚠️ 경로는 **같은 출처 안에서만** 받는다 — 서버 출처 검사가 다른 출처의 명령을 거절한다 (위 설명).
async function resolveFleet(base){
 const body=await fetch(base+'/api/fleet').then(response=>response.ok?response.json():null).catch(()=>null);
 const robots=Array.isArray(body?.robots)?body.robots.filter(r=>typeof r?.id==='string'&&typeof r?.base==='string'&&/^\/robots\/[A-Za-z0-9_-]{1,80}$/.test(r.base)):[];
 return robots.length?robots.slice(0,ROBOTS.length):null;
}
const fleetInfo=apiBase?await resolveFleet(apiBase):null;
// 자리(MD-01~03)마다 API 주소. 한 대짜리면 MD-01 하나가 이 출처 자체다.
const bases=Object.fromEntries(fleetInfo?fleetInfo.map((robot,index)=>[ROBOTS[index],apiBase+robot.base]):apiBase?[[ROBOTS[0],apiBase]]:[]);
const operations=fleetInfo
 ?new Operations({storage,fleet:fleetInfo.map((robot,index)=>({device:robot.id,registered:robot.registered!==false,link:new RobotLink({baseUrl:bases[ROBOTS[index]]})}))})
 :new Operations({storage,link:apiBase?new RobotLink({baseUrl:apiBase}):null});
// 음성 중계는 대시보드 명령 링크와 별개다 — voice_pipeline --web 이 떠 있으면
// 로컬 기본 주소(127.0.0.1:8090)로 자동으로 붙고, 없으면 패널이 준비만 표시한다.
const runtimeHealth=apiBase?await fetch(apiBase+'/health').then(r=>r.ok?r.json():null).catch(()=>null):null;
const voicePath=runtimeHealth?.capabilities?.voice_path;
const voiceBase=apiBase&&typeof voicePath==='string'&&/^\/api\/[a-z0-9-]+$/.test(voicePath)?apiBase+voicePath:await resolveVoiceBase();
const voiceLink=voiceBase?new VoiceLink({baseUrl:voiceBase}):null;
const visionAvailable={},feeds=[];
let visionRobot=null;
// 로봇 시점 창은 캔버스가 하나다 — **고른 로봇의** /ws/vision 만 붙인다. 로봇을 바꾸면 이전 연결을 닫는다
// (XIAO 스트림은 워커가 점유하고 여기서는 재송출만 받으므로, 세 채널을 늘 열어 둘 이유가 없다).
function syncVisionFeed(){
 const robot=operations.live?operations.selected:null;
 if(robot===visionRobot)return;
 visionFeed?.stop();visionFeed=null;visionRobot=robot;
 visionStatus={state:robot&&visionAvailable[robot]?'connecting':'off'};
 if(robot&&visionAvailable[robot]){
  visionFeed=new VisionFeed({url:bases[robot].replace(/^http/,'ws')+'/ws/vision',canvas:$('vision-frame'),onStatus:status=>{if(visionRobot===robot){visionStatus=status;syncVisionStatus()}}});
  visionFeed.start();
 }
 syncVisionStatus();
}
if(operations.connected){
 operations.setDemo(false);
 // 로봇 시점 창은 /ws/vision 을 그린다 (WBS 4.6.1) — 검출 박스와 그 박스를
 // 계산한 JPEG 가 한 메시지로 온다. 카메라 스트림에 박스를 얹지 않는다.
 // 비전을 끄고 띄우면(--no-vision) /health 의 vision_clients 가 null 이고
 // 채널이 없으므로 연결을 시도하지 않는다.
 const frame=$('vision-frame'),fpv=$('fpv');
 frame.hidden=false;
 if(fpv)fpv.hidden=true;
 // 관제 PC 방송 음량 · 무음 초기값 (4.8.2) — 방송기는 플릿 전체가 하나라 아무 로봇의 서버에서나 받는다.
 fetch(bases[ROBOTS[0]]+'/api/broadcast').then(response=>response.ok?response.json():null).then(state=>{if(state)operations.setBroadcast(state)}).catch(()=>{});
 await Promise.all(Object.entries(bases).map(async([robot,base])=>{
  const health=await fetch(base+'/health').then(response=>response.json()).catch(()=>null);
  operations.slot(robot).capabilities=health?.capabilities??{};
  operations.slot(robot).scene3dUrl=health?.dashboard?.scene3d_url||'';
  visionAvailable[robot]=health?.vision_clients!==null;
  // 명령 API 가 열렸는지. 옛 서버처럼 read_only 가 없으면 닫힌 것으로 본다.
  operations.setCommandsOpen(health?.read_only===false,robot);
  // 설정 화면의 단계 표 값 (B7). 못 받으면 화면이 «미수신» 이라고 적는다.
  fetch(base+'/api/policy').then(response=>response.ok?response.json():null).then(policy=>{if(policy)operations.setPolicy(policy,robot)}).catch(()=>{});
  // 실시간 사건도 같은 서버에서 온다 (WBS 4.6.4) — /ws/events 는 비전 채널과
  // 무관하게 항상 있다. 백로그를 먼저 넘겨주므로 늦게 열어도 최근 사건을 본다.
  const ws=base.replace(/^http/,'ws');
  feeds.push(new EventFeed({url:ws+'/ws/events',
   // 관제 방송 TTS 문장(4.8.2)이 실려 오면 화면 자막으로도 잠깐 띄운다 — 소리는
   // Host PC 스피커(`host/cloud/broadcast.py`)가 이미 낸다. 접속·재접속 때 서버가
   // 먼저 넘겨주는 지난 사건(백로그)까지 띄우지 않도록 방금(15초 안) 난 사건만 띄운다.
   onEvent:event=>{operations.ingestLiveEvent(event,base,robot);if(event.sentence&&Date.now()-event.ts_ms<15000)toast(event.sentence)},
   onGap:dropped=>operations.noteEventGap(dropped),
   onStatus:status=>operations.setEventFeed(status,robot)}));
  // 로봇 상태 게이지 (WBS 4.6.2) — /ws/telemetry 는 표시용 10Hz 다. 수신률은 새 seq 로만 센다.
  feeds.push(new TelemetryFeed({url:ws+'/ws/telemetry',onUpdate:view=>operations.setTelemetry(view,robot)}));
 }));
 for(const feed of feeds)feed.start();
 syncVisionFeed();
}
function toast(message){const node=$('toast');if(!node)return;node.textContent=message;node.hidden=false;clearTimeout(toastTimer);toastTimer=setTimeout(()=>node.hidden=true,5000)}
function attempt(action){try{return action()}catch(error){toast(error.message)}}
panels=new OperationalPanels({store:operations,container:$('panel-content'),title:$('panel-title'),onNavigate:navigate,onToast:toast,voiceLink,getVisionStatus:()=>visionStatus,
 onManualObservation:mount=>{
  if(mount)mount.append(cameraDock);
  else if(cameraDock.parentElement!==cameraHome)cameraHome.insertBefore(cameraDock,cameraNext);
  syncObservationView();view?.resize();
 },
 onFocusZone:zone=>{navigate('dashboard');view?.focusZone(zone);toast(zone.label+' · 예시 구역 위치')},
 onFocusRobot:id=>{navigate('dashboard');operations.selectRobot(id);view?.setView('robot')},
 onRobotPreview:canvas=>{
  if(!robotView){try{robotView=new RobotDetailView({canvas,onError:message=>panels.setRobotPreviewError(message)})}catch{panels.setRobotPreviewError('3D 모델을 표시하지 못했습니다. 상태 정보는 계속 확인할 수 있습니다.');return}}
  robotView.setActive(currentPage==='devices');robotView.resize();
 },
 onRobotViewAction:action=>{if(action==='reset')robotView?.reset();else if(action==='left')robotView?.orbit(-Math.PI/8);else if(action==='right')robotView?.orbit(Math.PI/8);else robotView?.zoom(action==='in'?.8:1.25)}
});

function syncObservationView(){
 const manual=currentPage==='missions',dashboard=currentPage==='dashboard';
 $('app').classList.toggle('observation-waiting',!operations.demo||operations.stale);
 view?.setWorldVisible(dashboard);
 // ⚠️ **실제 데이터 모드에서는 예시 공장 3D 를 그리지 않는다.** 지도가 없는데(LiDAR 미연결) 가상 공장과
 // 예시 로봇 2대·"확인 필요" 표시가 실제 화면에 섞이면 배치와 위치를 아는 것처럼 보인다. 숨긴 캔버스를
 // 계속 그릴 이유도 없다. LiDAR 지도가 생기면 이 자리는 2D 지도로 채운다.
 view?.setActive(!observationFailed&&operations.demo&&(dashboard||(manual&&!operations.stale)));
 view?.setCameraVisible(!observationFailed&&(dashboard||manual)&&operations.demo&&!operations.stale&&(manual||!cameraDock.classList.contains('collapsed')));
}
function reportObservationError(message){
 observationFailed=true;panels.setObservationError(message);operations.suspend('3D 렌더링 중단');syncObservationView();$('scene-failure').hidden=false;toast(message);
}
scene3d=new Scene3D({document,mount:$('scene3d-mount'),controls:$('scene3d-controls'),notice:$('scene3d-notice'),onChange:showLiveMap});
function syncMain(){
 const selected=operations.selected,playing=operations.demo&&!operations.stale&&!operations.estop&&operations.mission.status==='running';
 view?.selectRobot(selected);view?.setPatrolRobot(operations.mission.robot);view?.setPlaying(playing);
 syncObservationView();
 robotView?.setActive(currentPage==='devices');
 document.querySelectorAll('[data-robot]').forEach(element=>{const active=element.dataset.robot===selected;element.classList.toggle('selected',active);element.setAttribute('aria-pressed',String(active))});
 // 실제 연결에서는 서버에 붙은 로봇만 보인다 — 한 대짜리면 MD-01 하나, 플릿이면 서버가 알려 준 만큼 (operations.robots).
 for(const element of document.querySelectorAll('.robot-tab,.camera-robot-switch [data-robot]'))element.hidden=!operations.robots.includes(element.dataset.robot);
 syncVisionFeed();
 $('app').classList.toggle('data-waiting',!operations.demo);
 $('source-status').textContent=operations.demo?(operations.stale?'웹 예시 · 수신 만료 시험':'웹 예시'):operations.runtimeLabel;
 // ⚠️ **머리글의 제어 문구도 사실대로 말한다.** 연결돼 있는데 "정지 명령 전달 불가" 라고 적혀 있으면
 // 운용자가 비상정지를 누르지 않거나, 반대로 화면 문구를 믿고 물리 정지 수단을 찾는다.
 {const note=document.querySelector('.safety-note>span:last-child');note.firstChild.nodeValue=operations.live&&!operations.readOnly?'실시간 제어 연결 ':'실시간 제어 잠김 ';note.querySelector('small').textContent=operations.readOnly?'조회·계획 전용 · 정지 명령 전달 불가':operations.live?'비상정지 즉시 전송':'미연결 · 정지 명령 전달 불가';}
 // 웹 시연 임무 칸은 실제 연결에서 숨긴다 — 실제 순찰과 헷갈린다. 실제 순찰은 제어 · 장치 화면에 있다.
 document.querySelector('.mission-summary').hidden=operations.live;
 syncTelemetry();
 $('scene-subtitle').textContent=operations.demo?'예시 공간 · 실제 위치 미수신':'지도 없음 · 예시 공장 숨김';
 $('map-placeholder').hidden=operations.demo||(operations.live&&mapAvailable);
 // 실제 집 지도 — 관제 서버에 붙었을 때만. 지도를 누르면 확인 창을 거쳐 로봇을 보낸다.
 if(operations.live&&!mainLiveMap&&panels){mainLiveMap=new LiveMap({document,getLink:()=>operations.live?operations.link:null,onPick:(x,y,where)=>panels.confirmGoto(x,y,where),onAvailability:available=>{mapAvailable=available;showLiveMap()}});$('live-house-map').append(mainLiveMap.root)}
 scene3d.setActive(currentPage==='dashboard');
 scene3d.setUrl(operations.live?operations.slot(operations.selected).scene3dUrl:'');
 showLiveMap();
 if(operations.live)syncVisionStatus();
 else{
  $('app').classList.remove('vision-has-frame');
  $('frame-source').textContent=operations.demo?(operations.stale?'예시 수신 만료 · 갱신 대기':'예시 화면 · 실시간 아님'):'영상 미수신 · 연결 대기';
  $('camera-status').textContent='실제 영상 미연결';
  $('camera-resolution').hidden=true;
  $('frame-time').innerHTML='마지막 영상 수신　— <span class="muted">· 관측 전용</span>';
 }
 $('estop').classList.toggle('preview-latched',operations.estop);
 $('estop').classList.toggle('is-live',operations.live&&!operations.readOnly);
 $('stop-label').firstChild.nodeValue=operations.live&&!operations.readOnly?'긴급 정지':'정지 안내';
 $('estop').setAttribute('aria-label',operations.readOnly?'정지 안내 · 조회·계획 전용 화면':operations.live?'긴급 정지 · 로봇에 즉시 전송':operations.estop?'정지 안내 · 웹 예시 정지 중':'정지 안내 · 실제 장비 미연결');
 // 버튼에 적힌 말과 실제로 하는 일이 다르면 안 된다.
 {const note=$('estop').querySelector('.mobile-stop-note');if(note)note.textContent=operations.readOnly?'조회·계획 전용':operations.live?'연결됨 · 즉시 전송':'실제 정지 불가';}
 $('demo-toggle').innerHTML=icon(playing?'pause':'play');
 $('demo-toggle').setAttribute('aria-label',playing?'예시 순찰 일시정지':operations.mission.status==='paused'?'예시 순찰 재개':'예시 순찰 준비');
 $('demo-toggle').disabled=operations.blocked&&!playing;
 const missionStatus={idle:'대기',running:'점검',paused:'일시정지',ended:'종료'}[operations.mission.status];
 $('demo-status').textContent=missionStatus;
 document.querySelector('.mission-heading h2').textContent='예시 임무 · '+(operations.mission.status==='idle'?'시작 전':operations.mission.zone+' · '+missionStatus);
 document.querySelectorAll('.mission-progress .step').forEach((element,index)=>{element.classList.remove('done');element.classList.toggle('current',index===(operations.mission.status==='idle'?0:['running','paused'].includes(operations.mission.status)?1:2));element.textContent=index===0?'대기':index===1?(operations.mission.status==='paused'?'일시정지':'점검'):'종료'});
 const events=operations.queryEvents(),pending=events.filter(event=>event.review==='pending').length;
 const liveCount=events.filter(event=>event.source==='LIVE_FEED').length;
 document.querySelector('.event-summary strong').textContent=(operations.demo?'예시·저장 사건':'저장 사건')+' · 검토 대기 '+pending+'건';
 document.querySelector('.event-summary p').textContent=liveCount?'실시간 '+liveCount+'건 포함':events.length?'':'수신된 사건 없음';
 $('attention-marker').setAttribute('aria-label','예시 사건 검토 열기');
}
// 하단 상태 칸 — 연결 여부와 로봇 상태를 **사실대로** 말한다 (4.6.2). 연결이 없으면 예시 문구다.
// 연결됐어도 로봇에서 받은 값이 없거나 끊겼으면 그렇게 말한다 — 아는 척하지 않는다.
function syncTelemetry(){
 syncRobotLabels();
 syncAlarm();
 const card=document.querySelector('.actual-status');
 if(!operations.live){card.dataset.tone='off';card.querySelector('strong').textContent='현장 상태 확인 불가 · 장비 미연결';card.querySelector('p').textContent='';$('state-time').textContent='—';return}
 const text=describeTelemetry(operations.telemetry);
 card.dataset.tone=text.tone;card.querySelector('strong').textContent=text.headline;card.querySelector('p').textContent=text.summary;
 $('state-time').textContent=text.age;
}
// 로봇 이름과 연결 칸. 실제 연결이면 서버가 알려 준 개체 이름과 **로봇 수신 상태**를 쓴다 —
// 예전에는 연결돼 있어도 탭이 "MD-01 · 미연결" 이었다. 이름은 첫 상태 전문에 실려 오므로 10Hz 경로에서 맞춘다.
function syncRobotLabels(){
 const name=operations.robotName(operations.selected),text=operations.live?describeTelemetry(operations.telemetry):null;
 $('camera-title').textContent=name+' · 로봇 시점';$('camera-axis').textContent=name+' / FRONT';
 // 탭마다 **그 로봇의** 수신 상태다. 실물이 아직 없는 자리(텔레메트리 ID 미설정)는 받은 것이 없으면 «미등록».
 for(const tab of document.querySelectorAll('.robot-tab')){
  const id=tab.dataset.robot,strong=tab.querySelector('strong');
  strong.firstChild.nodeValue=operations.robotName(id)+(strong.children.length?' ':'');
  const telemetry=operations.telemetryOf(id),own=operations.live&&!tab.hidden?describeTelemetry(telemetry):null;
  // ⚠️ «미등록» 은 텔레메트리가 와도 뗀다 — 검증할 MAC 이 없어 이름만으로 받은 것이다.
  tab.querySelector('.robot-health').lastChild.nodeValue=!own?'미연결':(!operations.isRegistered(id)?'미등록 · ':'')+own.badge[0];
 }
 for(const button of document.querySelectorAll('.camera-robot-switch [data-robot]'))button.textContent=operations.robotName(button.dataset.robot);
 document.querySelector('.source-status .muted').textContent=text?'로봇 '+text.badge[0]:'실제 장비 미연결';
}
// 경보 띠 (B1 · TC-F-013 «음성 미장착 시 시각 경보»). L2·L3·F 에서만 뜬다. 단계는 상태 전문, 사유·경고 문장은
// 같은 단계의 마지막 단계 사건에서 온다. ⚠️ L3 확인과 F 해제는 다른 버튼이다 — 띠는 처리 화면으로 안내만 한다.
const ALARM_TEXT={L2:'L2 · 인증 대응 — 미인증 대상에게 신원 확인을 요구하는 중',L3:'L3 · 경보 — 관리자 확인이 필요합니다 («경보 확인»)',F:'F · 안전 잠금 — 원인 확인 뒤 «안전 해제 (RESET_SAFE)»'};
// 여러 대면 **가장 심한 로봇**을 띠에 싣고, 나머지는 이름·단계만 덧붙인다. 보고 있는 로봇이 아니어도 뜬다.
let alarmRobot=null;
function syncAlarm(){
 const [alarm,...others]=operations.alarms,banner=$('alarm-banner'),many=operations.robots.length>1;
 banner.hidden=!alarm;alarmRobot=alarm?.robot??null;if(!alarm)return;
 banner.dataset.level=alarm.level;banner.classList.toggle('stale',alarm.stale);
 const [head,...rest]=ALARM_TEXT[alarm.level].split(' — ');
 $('alarm-level').textContent=(many?alarm.name+' · ':'')+head;
 $('alarm-text').textContent=[rest.join(' — '),alarm.reason&&'사유 '+alarm.reason,alarm.warning&&'경고 「'+alarm.warning+'」',alarm.stale&&'수신 끊김 · 마지막 값',others.length&&'다른 로봇 '+others.map(other=>other.name+' '+other.level).join(', ')].filter(Boolean).join(' · ');
 $('alarm-action').hidden=alarm.level==='L2'||(currentPage==='missions'&&operations.selected===alarm.robot);
}
$('alarm-action').addEventListener('click',()=>{if(alarmRobot&&alarmRobot!==operations.selected)attempt(()=>operations.selectRobot(alarmRobot));navigate('missions')});
// 텔레메트리는 초당 10번 온다 — 화면 전체(syncMain)를 다시 맞추지 않고 상태 칸과 게이지만 고친다.
operations.subscribe(reason=>{if(reason==='telemetry'){syncTelemetry();panels.refresh(reason);return}syncMain();panels.refresh(reason)});

function navigate(page){
 const target=['dashboard','missions','events','records','zones','devices','voice','settings'].includes(page)?page:'dashboard';
 if(location.hash!=='#'+target)location.hash=target;
 openPage(target);
}
function openRobotDetail(id){
 if(currentPage==='dashboard')lastOpener=document.activeElement;
 operations.selectRobot(id);navigate('devices');
}
function openPage(page){
 if(currentPage===page&&((page==='dashboard'&&$('detail-panel').hidden)||!$('detail-panel').hidden))return;
 operations.release('화면 전환');
 if(currentPage==='dashboard'&&page!=='dashboard')lastOpener=document.activeElement;
 currentPage=page;const isDashboard=page==='dashboard';
 $('app').classList.toggle('workspace-open',!isDashboard);
 for(const element of document.querySelectorAll('.fleet-band,#stage,.operation-rail'))element.hidden=!isDashboard;
 $('detail-panel').hidden=isDashboard;
 document.querySelector('.skip-link').href=isDashboard?'#scene-title':'#panel-title';
 document.querySelectorAll('[data-view]').forEach(button=>{const active=button.dataset.view===page;button.classList.toggle('active',active);if(active)button.setAttribute('aria-current','page');else button.removeAttribute('aria-current')});
 const more=document.querySelector('.nav-more'),inMore=!!more.querySelector('[data-view].active');
 // 닫힌 메뉴 안의 aria-current 는 보조기기에 보이지 않으므로 메뉴 제목에도 현재 위치를 싣는다.
 more.classList.toggle('active',inMore);if(inMore)more.querySelector('summary').setAttribute('aria-current','true');else more.querySelector('summary').removeAttribute('aria-current');
 more.open=false;
 document.querySelectorAll('[data-camera]').forEach(button=>{const active=button.dataset.camera===(page==='zones'?'top':page==='devices'?'robot':page==='dashboard'?'overview':'none');button.classList.toggle('selected',active);button.setAttribute('aria-pressed',String(active))});
 panels.render(page);
 if(page==='dashboard'){const fallback=document.querySelector('.robot-tab[data-robot="'+operations.selected+'"]');(lastOpener?.isConnected&&lastOpener.matches('button,a')&&!lastOpener.closest('[hidden],details:not([open])')?lastOpener:fallback||$('scene-title')).focus();lastOpener=null}
 else{$('panel-title').focus();$('panel-content').scrollTop=0}
 syncMain();
 operations.log('화면 열기',page);
}
window.addEventListener('hashchange',()=>{const page=location.hash.slice(1);navigate(page==='history'?'records':page)});
document.querySelector('.skip-link').addEventListener('click',event=>{event.preventDefault();(currentPage==='dashboard'?$('scene-title'):$('panel-title')).focus()});
for(const id of ROBOTS){const marker=document.createElement('button');marker.className='map-marker';marker.dataset.robot=id;marker.append(document.createTextNode(id+' · '));const small=document.createElement('small');small.textContent='예시';marker.append(small);$('markers').append(marker)}
document.querySelectorAll('[data-robot]').forEach(element=>element.addEventListener('click',()=>element.closest('.camera-robot-switch')?operations.selectRobot(element.dataset.robot):openRobotDetail(element.dataset.robot)));
document.querySelectorAll('[data-view]').forEach(element=>element.addEventListener('click',()=>navigate(element.dataset.view)));
document.querySelectorAll('[data-camera]').forEach(element=>element.addEventListener('click',()=>{const mode=element.dataset.camera;if(mode==='overview'){navigate('dashboard');view?.setView('overview')}else navigate(mode==='top'?'zones':'devices')}));
$('close-panel').addEventListener('click',()=>navigate('dashboard'));
$('open-events').addEventListener('click',()=>navigate('events'));
$('attention-marker').addEventListener('click',()=>navigate('events'));
$('zoom-in').addEventListener('click',()=>mapAvailable&&operations.live?mainLiveMap?.zoom(.8):view?.zoom(.8));$('zoom-out').addEventListener('click',()=>mapAvailable&&operations.live?mainLiveMap?.zoom(1.25):view?.zoom(1.25));
$('orbit-left').addEventListener('click',()=>mapAvailable&&operations.live?mainLiveMap?.orbit(Math.PI/8):view?.orbit(Math.PI/8));
$('reset-view').addEventListener('click',()=>{if(mapAvailable&&operations.live)mainLiveMap?.resetView();else view?.setView('overview');toast('기본 시야로 돌아왔어요.')});
$('fullscreen').addEventListener('click',async()=>{try{if(document.fullscreenElement)await document.exitFullscreen();else await document.documentElement.requestFullscreen()}catch{toast('이 브라우저에서는 전체 화면을 사용할 수 없어요.')}});
function setCameraDockState({expanded=false,collapsed=false}){
 const dock=$('camera-dock'),expand=$('expand-camera'),collapse=$('collapse-camera');
 if(expanded&&!dock.classList.contains('expanded'))dock.expandDockInPlace?.();
 else if(!expanded&&dock.classList.contains('expanded'))dock.restoreDockBeforeExpand?.();
 dock.classList.toggle('expanded',expanded);dock.classList.toggle('collapsed',collapsed);
 const expandLabel=expanded?'로봇 시점 원래 크기로':'로봇 시점 크게 보기';
 expand.setAttribute('aria-label',expandLabel);expand.title=expandLabel;
 expand.querySelector('span:last-child').textContent=expanded?'축소':'확대';
 collapse.setAttribute('aria-expanded',String(!collapsed));
 collapse.setAttribute('aria-label',collapsed?'로봇 시점 펼치기':'로봇 시점 접기');
 collapse.innerHTML=icon(collapsed?'plus':'minus')+'<span>'+(collapsed?'펼치기':'접기')+'</span>';
 syncObservationView();
 // ResizeObserver also follows later viewport changes.
 view?.resize();
}
$('expand-camera').addEventListener('click',()=>setCameraDockState({expanded:!$('camera-dock').classList.contains('expanded')}));
$('collapse-camera').addEventListener('click',()=>setCameraDockState({collapsed:!$('camera-dock').classList.contains('collapsed')}));
// 카메라 창 자유 배치 — 헤더를 끌어 옮기고, 변·모서리를 끌어 크기를 바꾼다.
// 통합 관제에서만 동작한다 — 제어 · 장치에서는 칸이 문서 흐름(position:static)이라
// 끌면 레이아웃이 깨진다. 크기는 너비만 바꾸고 높이는 --vision-aspect 가 맞춘다.
{
 const stage=$('stage'),dock=cameraDock,header=dock.querySelector('.camera-header');
 const clampTo=(v,min,max)=>Math.min(max,Math.max(min,v));
 const dockInStage=()=>dock.parentElement===stage&&currentPage==='dashboard';
 // 확대 전 크기와 위치를 기억한다. 확대 상태에서도 이동·크기 조절이 가능하다.
 let beforeExpandGeom=null;
 const expandInPlace=()=>{
  beforeExpandGeom={left:dock.style.left,top:dock.style.top,bottom:dock.style.bottom,width:dock.style.width};
  const s=stage.getBoundingClientRect(),d=dock.getBoundingClientRect();
  const maxVideoWidth=(s.height-160)*(visionStatus.width>0&&visionStatus.height>0?visionStatus.width/visionStatus.height:4/3)+18;
  const width=Math.min(920,s.width-20,maxVideoWidth,Math.max(d.width,s.width*.75));
  dock.style.left=clampTo(d.left-s.left,0,Math.max(0,s.width-width))+'px';
  dock.style.top='auto';dock.style.bottom=Math.max(0,s.bottom-d.bottom)+'px';dock.style.width=width+'px';
 };
 const restoreBeforeExpand=()=>{if(beforeExpandGeom)Object.assign(dock.style,beforeExpandGeom);beforeExpandGeom=null};
 dock.expandDockInPlace=expandInPlace;dock.restoreDockBeforeExpand=restoreBeforeExpand;
 header.addEventListener('pointerdown',event=>{
  if(!dockInStage()||matchMedia('(max-width:800px)').matches||event.target.closest('button'))return;
  event.preventDefault();
  const s=stage.getBoundingClientRect(),d=dock.getBoundingClientRect();
  dock.style.left=(d.left-s.left)+'px';dock.style.top=(d.top-s.top)+'px';dock.style.bottom='auto';
  const offX=event.clientX-d.left,offY=event.clientY-d.top;
  const move=move=>{
   dock.style.left=clampTo(move.clientX-s.left-offX,0,Math.max(0,s.width-dock.offsetWidth))+'px';
   dock.style.top=clampTo(move.clientY-s.top-offY,0,Math.max(0,s.height-dock.offsetHeight))+'px';
  };
  const up=()=>{header.removeEventListener('pointermove',move);header.removeEventListener('pointerup',up);header.removeEventListener('pointercancel',up);view?.resize()};
  header.setPointerCapture?.(event.pointerId);
  header.addEventListener('pointermove',move);
  header.addEventListener('pointerup',up);
  header.addEventListener('pointercancel',up);
 });
 const aspect=()=>{const w=visionStatus.width,h=visionStatus.height;return w>0&&h>0?w/h:4/3};
 for(const grip of dock.querySelectorAll('.camera-resize'))grip.addEventListener('pointerdown',event=>{
  if(!dockInStage())return;
  event.preventDefault();
  const edge=grip.dataset.edge,s=stage.getBoundingClientRect(),startW=dock.getBoundingClientRect().width,startX=event.clientX,startY=event.clientY;
  const move=move=>{
   const dx=move.clientX-startX,dy=move.clientY-startY;
   const verticalGrowth=dy*aspect();
   const grown=edge==='e'?dx:edge==='s'?verticalGrowth:Math.abs(dx)>=Math.abs(verticalGrowth)?dx:verticalGrowth;
   const videoHeight=s.height-(dock.classList.contains('expanded')?160:180);
   const maxWidth=Math.min(s.width-20,1100,videoHeight*aspect()+18);
   dock.style.width=clampTo(startW+grown,Math.min(280,maxWidth),maxWidth)+'px';
   // 너비가 커지면 오른쪽 경계를 넘을 수 있다 — 왼쪽을 당겨 안에 둔다.
   const over=dock.getBoundingClientRect().right-s.right;
   if(over>0)dock.style.left=clampTo((dock.offsetLeft||0)-over,0,s.width)+'px';
  };
  const up=()=>{grip.removeEventListener('pointermove',move);grip.removeEventListener('pointerup',up);grip.removeEventListener('pointercancel',up);view?.resize()};
  grip.setPointerCapture?.(event.pointerId);
  grip.addEventListener('pointermove',move);
  grip.addEventListener('pointerup',up);
  grip.addEventListener('pointercancel',up);
 });
}
$('demo-toggle').addEventListener('click',()=>attempt(()=>{if(operations.mission.status==='running')operations.pauseMission();else if(operations.mission.status==='paused')operations.resumeMission();else navigate('missions')}));
function openStopDialog(){operations.suspend('긴급 정지 안내 열기');if(!$('stop-dialog').open)$('stop-dialog').showModal()}
// 연결돼 있으면 비상정지는 한 번 눌러 바로 나간다. 모달을 한 단계 끼우면 급할 때
// 그만큼 늦고, 그 모달은 "장비가 연결되지 않았어요" 라고 거짓을 말한다. 연결이
// 없을 때만 안내를 띄운다 — 그때는 실제로 보낼 곳이 없다.
function onEstopPressed(){
 if(operations.readOnly){toast('조회·계획 전용 서버입니다. 이 화면에서는 실제 정지 명령을 보낼 수 없습니다.');return}
 if(operations.live){
  operations.requestEstop().then(({serverAccepted})=>toast(serverAccepted
   ?'서버가 비상정지 명령을 보냈습니다. 실제 정지는 본체 상태로 확인하세요.'
   :operations.linkError||'비상정지 전달을 확인하지 못했습니다. 본체 전원 스위치를 확인하세요.'));
  return;
 }
 openStopDialog();
}
$('estop').addEventListener('click',onEstopPressed);
$('stop-preview').addEventListener('click',()=>operations.requestEstop());
document.addEventListener('keydown',event=>{
 if(event.key==='Escape'){operations.stop('Escape');document.querySelector('.nav-more').open=false;if(!$('stop-dialog').open)navigate('dashboard')}
 // 단축키도 버튼과 **같은 경로**를 탄다 (FR-4.4). 예전에는 여기서 모달만 열어
 // 연결돼 있어도 한 번 더 눌러야 나갔다 — 버튼 쪽 주석이 "모달을 한 단계 끼우면
 // 급할 때 그만큼 늦다" 고 적어 둔 바로 그 문제를 단축키만 안고 있었다.
 if(event.shiftKey&&event.key.toLowerCase()==='e'&&!/INPUT|TEXTAREA|SELECT/.test(event.target.tagName)){onEstopPressed();event.preventDefault()}
});
document.addEventListener('visibilitychange',()=>{if(document.hidden)operations.suspend('페이지 숨김 · 자동 재개 안 함')});
window.addEventListener('blur',()=>operations.suspend('창 초점 이탈 · 자동 재개 안 함'));
window.addEventListener('pagehide',event=>{operations.suspend('페이지 종료');if(!event.persisted){visionFeed?.stop();for(const feed of feeds)feed.stop();robotView?.dispose();panels.dispose();mainLiveMap?.dispose();scene3d?.dispose();view?.dispose()}});
const unregisterTools=registerPageTools({document,store:operations,navigate,onError:()=>operations.log('페이지 도구 등록 실패','일반 화면 조작은 계속 사용 가능')});
window.addEventListener('pagehide',event=>{if(!event.persisted)unregisterTools()});
$('retry-render').addEventListener('click',()=>location.reload());
syncMain();navigate(location.hash.slice(1)||'dashboard');

try{
 const response=await fetch('./factory-layout.json');if(!response.ok)throw new Error('공장 레이아웃을 불러오지 못했습니다.');
 const layout=await response.json();panels.setZones(layout.zones);
 view=new FactoryView({worldCanvas:$('world'),fpvCanvas:$('fpv'),layout,onRobot:openRobotDetail,onObservation:observation=>panels.updateRobotObservation(observation),onError:reportObservationError,onProject:positions=>{for(const position of positions){const marker=position.id==='attention'?$('attention-marker'):$('markers').querySelector('[data-robot="'+position.id+'"]');marker.style.left=position.x+'px';marker.style.top=position.y+'px';marker.hidden=!position.visible}}});
 renderRobotPreviews(document.querySelectorAll('.robot-preview'));syncMain();operations.log('3D 현장 열기','신규 공장 · 웹 시각 예시');
}catch(error){reportObservationError(error.message)}
