"""범용 객체 검출 (WBS 3.3.1 · FR-3.1.2 · ADR-12 · ADR-13 · ADR-24).

검출기를 갈아 끼울 수 있게 세 겹으로 나눈다.

    ① `DetectorAdapter`  모델 고유 부분 — 전처리 규약과 출력 디코딩
    ② `nms` · `Detector`  모델 무관 부분 — 세션 관리, 억제, 좌표 복원, 게이팅
    ③ `ADAPTERS`          `vision.coco.model_family` 로 ①을 고른다

채택 계열은 YOLOX-S(Apache-2.0)다. 세션은 주입받은 `session_factory` 가 만들고 전·후처리는
배열만 다루는 순수 함수라 가중치 없이 시험된다. 가중치(`models/`, 저장소 밖)가 없으면
`ModelMissingError` 로 획득 절차를 알리며 멈춘다.
"""

from __future__ import annotations

import time
from collections.abc import Callable, Mapping, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Protocol, cast

import numpy as np

from host.common.config import repo_path
from host.common.logging_setup import event_logger
from host.vision.providers import log_selection, select_providers

LOG = event_logger("mechadog.vision")


class ModelMissingError(RuntimeError):
    """가중치 파일이 없음 — 빈 결과를 내지 않고 멈춘다."""


@dataclass(frozen=True, slots=True)
class Detection:
    """검출 하나. 좌표는 원본 프레임 기준이다(letterbox 를 되돌렸다)."""

    label: str
    score: float
    #: (x1, y1, x2, y2) — 원본 픽셀 좌표
    box: tuple[float, float, float, float]


@dataclass(frozen=True, slots=True)
class Preprocessed:
    """전처리 결과와 모델 좌표를 원본으로 되돌리는 데 필요한 비율."""

    tensor: np.ndarray
    ratio: float


class DetectorAdapter(Protocol):
    """모델 고유 부분 — 계열을 바꿀 때 여기만 갈아 끼운다."""

    #: 모델이 받는 정사각 입력 변의 길이
    input_size: int

    def preprocess(self, image: np.ndarray) -> Preprocessed:
        """BGR 이미지를 모델 입력 텐서로. 정규화 규약은 모델마다 다르다."""
        ...

    def decode(self, outputs: Sequence[np.ndarray]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """원시 출력을 `(boxes_xyxy, scores, class_ids)` 로. 모델 좌표계 그대로 낸다."""
        ...


# ── ① YOLOX 고유 부분 ───────────────────────────────────────
#: YOLOX 는 letterbox 여백을 이 값으로 채운다. 0(검정)으로 채우면 여백이 물체처럼 보인다.
YOLOX_PAD_VALUE = 114

#: 출력 격자의 stride. 640 입력이면 80²+40²+20² = 8400 개 후보가 나온다.
YOLOX_STRIDES = (8, 16, 32)


class YoloxAdapter:
    """YOLOX 계열(Apache-2.0, Megvii) 어댑터 — 원본 `preproc()` 규약을 따른다 (ADR-24).

    입력은 0~255 그대로(정규화 없음)·BGR·좌상단 정렬 letterbox(여백 114)·축소 버림이다.
    `/255` 를 넣으면 예외 없이 빈 결과가 나온다.
    """

    def __init__(self, input_size: int) -> None:
        if input_size <= 0 or input_size % max(YOLOX_STRIDES) != 0:
            raise ValueError(
                f"input_size 는 {max(YOLOX_STRIDES)} 의 양의 배수여야 함: {input_size}"
            )
        self.input_size = int(input_size)
        # 입력 크기가 고정된 동안 좌표 격자도 같다. 프레임마다 재할당하지 않는다.
        self._grid_data = self._grid()
        for values in self._grid_data:
            values.flags.writeable = False

    def preprocess(self, image: np.ndarray) -> Preprocessed:
        if image.ndim != 3 or image.shape[2] != 3:
            raise ValueError(f"HxWx3 BGR 이미지가 필요함: shape={image.shape}")
        import cv2

        size = self.input_size
        height, width = image.shape[:2]
        ratio = min(size / height, size / width)
        # 버림이다 — 원본 `preproc` 의 `int(shape * r)` 와 같다.
        resized = cv2.resize(
            image,
            (int(width * ratio), int(height * ratio)),
            interpolation=cv2.INTER_LINEAR,
        )
        canvas = np.full((size, size, 3), YOLOX_PAD_VALUE, dtype=np.uint8)
        canvas[: resized.shape[0], : resized.shape[1]] = resized
        # HWC(BGR) → CHW, float32. 스케일 변환은 하지 않는다.
        tensor = np.ascontiguousarray(canvas.transpose(2, 0, 1)[None], dtype=np.float32)
        return Preprocessed(tensor=tensor, ratio=ratio)

    def _grid(self) -> tuple[np.ndarray, np.ndarray]:
        """격자 좌표와 stride. 출력 순서(8→16→32)에 맞춰 이어 붙인다."""
        grids: list[np.ndarray] = []
        strides: list[np.ndarray] = []
        for stride in YOLOX_STRIDES:
            side = self.input_size // stride
            xv, yv = np.meshgrid(np.arange(side), np.arange(side))
            grid = np.stack((xv, yv), axis=2).reshape(-1, 2)
            grids.append(grid)
            strides.append(np.full((grid.shape[0], 1), stride))
        return np.concatenate(grids, axis=0), np.concatenate(strides, axis=0)

    def decode(self, outputs: Sequence[np.ndarray]) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """`[1, 8400, 85]` → 박스·점수·클래스.

        85 = 중심 오프셋 2 + 크기 로그 2 + objectness 1 + 클래스 80. 점수는 objectness × 클래스 확률이다.
        """
        raw = np.asarray(outputs[0], dtype=np.float32)
        if raw.ndim == 3:
            raw = raw[0]
        if raw.ndim != 2 or raw.shape[1] < 6:
            raise ValueError(f"[N, 5+클래스] 출력이 필요함: shape={raw.shape}")

        grid, stride = self._grid_data
        if raw.shape[0] != grid.shape[0]:
            raise ValueError(
                f"후보 수가 격자와 다름 — input_size 가 모델과 어긋났다: "
                f"출력={raw.shape[0]} 격자={grid.shape[0]}"
            )

        centers = (raw[:, 0:2] + grid) * stride
        sizes = np.exp(raw[:, 2:4]) * stride
        half = sizes / 2.0
        boxes = np.concatenate([centers - half, centers + half], axis=1)

        class_scores = raw[:, 5:]
        class_ids = class_scores.argmax(axis=1)
        scores = raw[:, 4] * class_scores[np.arange(class_scores.shape[0]), class_ids]
        return boxes, scores, class_ids


#: `vision.coco.model_family` 값 → 어댑터. 새 계열은 여기 한 줄만 늘린다.
ADAPTERS: dict[str, Callable[[int], DetectorAdapter]] = {"yolox": YoloxAdapter}


def build_adapter(family: str, input_size: int) -> DetectorAdapter:
    """설정값으로 어댑터를 만든다. 모르는 이름은 `ValueError` 로 거부한다 (ADR-24)."""
    try:
        adapter_type = ADAPTERS[family]
    except KeyError:
        raise ValueError(f"모르는 model_family: {family!r}. 가능한 값={sorted(ADAPTERS)}") from None
    return adapter_type(input_size)


# ── ② 모델 무관 부분 ────────────────────────────────────────
def nms(
    boxes: np.ndarray,
    scores: np.ndarray,
    iou_threshold: float,
) -> list[int]:
    """겹치는 박스를 억제하고 남길 인덱스를 점수 내림차순으로 낸다(모델 무관)."""
    if boxes.shape[0] == 0:
        return []
    x1, y1, x2, y2 = boxes[:, 0], boxes[:, 1], boxes[:, 2], boxes[:, 3]
    areas = np.clip(x2 - x1, 0, None) * np.clip(y2 - y1, 0, None)
    order = scores.argsort()[::-1]

    keep: list[int] = []
    while order.size > 0:
        best = int(order[0])
        keep.append(best)
        if order.size == 1:
            break
        rest = order[1:]
        inter_w = np.clip(np.minimum(x2[best], x2[rest]) - np.maximum(x1[best], x1[rest]), 0, None)
        inter_h = np.clip(np.minimum(y2[best], y2[rest]) - np.maximum(y1[best], y1[rest]), 0, None)
        inter = inter_w * inter_h
        union = areas[best] + areas[rest] - inter
        # 면적 0 인 박스가 섞이면 0 나눗셈이 된다 — 그런 박스는 겹치지 않은 것으로 본다.
        iou = np.where(union > 0, inter / np.maximum(union, 1e-9), 0.0)
        order = rest[iou <= iou_threshold]
    return keep


class Detector:
    """세션 하나를 들고 프레임을 검출로 바꾼다. 모델 계열을 모른다.

    스레드 안전하지 않다. `detect()` 는 세션이 없으면 먼저 연다.
    """

    def __init__(
        self,
        config: Mapping[str, Any],
        *,
        section: str = "coco",
        labels: Sequence[str],
        session_factory: Any | None = None,
    ) -> None:
        vision = config["vision"]
        spec = vision[section]
        family = spec.get("model_family")
        if not family:
            raise ValueError(
                f"vision.{section}.model_family 가 비어 있다 — 재현을 위해 계열을 기록한다"
            )
        self._adapter = build_adapter(str(family), int(spec["input_size"]))
        self._labels = tuple(labels)
        self._conf = float(spec["conf_threshold"])
        self._iou = float(spec.get("iou_threshold", 0.45))
        self._model_path = repo_path(spec["model_path"])
        self._preferred = list(vision["providers"])
        self._factory = session_factory or _make_onnx_session
        self._session: Any | None = None

    @property
    def adapter(self) -> DetectorAdapter:
        return self._adapter

    def open(self) -> None:
        """세션을 만들고 전처리 → 추론을 한 번 흘려 데운다.

        첫 프레임 비용의 대부분은 OpenCV 첫 호출 초기화라 세션만이 아니라 전처리까지 흘린다
        (ADR-24 «실측이 드러낸 것»).
        """
        if self._session is not None:
            return
        self._session = self._factory(self._model_path, self._preferred)
        self._warm_up()

    def _warm_up(self) -> None:
        """빈 프레임으로 전처리 → 추론을 한 번 지나간다. 결과는 쓰지 않는다."""
        assert self._session is not None
        size = self._adapter.input_size
        started = time.perf_counter()
        # 어댑터의 전처리를 통과시켜 OpenCV 초기화까지 여기서 끝낸다.
        prep = self._adapter.preprocess(np.zeros((size, size, 3), dtype=np.uint8))
        self._session.run(None, {self._input_name(): prep.tensor})
        LOG.info("detector_warmed_up", ms=round((time.perf_counter() - started) * 1000, 1))

    def detect(self, image: np.ndarray) -> list[Detection]:
        """프레임 하나 → 검출 목록. 임계값 미달과 겹침은 여기서 걸러진다."""
        self.open()
        assert self._session is not None
        prep = self._adapter.preprocess(image)
        outputs = self._session.run(None, {self._input_name(): prep.tensor})
        boxes, scores, class_ids = self._adapter.decode(outputs)
        return self._finalize(boxes, scores, class_ids, prep, image.shape[:2])

    def _input_name(self) -> str:
        assert self._session is not None
        return cast(str, self._session.get_inputs()[0].name)

    def _finalize(
        self,
        boxes: np.ndarray,
        scores: np.ndarray,
        class_ids: np.ndarray,
        prep: Preprocessed,
        shape: tuple[int, int],
    ) -> list[Detection]:
        above = scores >= self._conf
        boxes, scores, class_ids = boxes[above], scores[above], class_ids[above]
        if boxes.shape[0] == 0:
            return []

        # letterbox 되돌리기 → 원본 좌표. 그다음에 화면 밖을 잘라낸다.
        boxes = boxes / prep.ratio
        height, width = shape
        boxes[:, 0::2] = np.clip(boxes[:, 0::2], 0, width)
        boxes[:, 1::2] = np.clip(boxes[:, 1::2], 0, height)

        results: list[Detection] = []
        # 클래스별로 억제한다 — 겹친 사람과 의자가 하나로 합쳐지지 않게.
        for class_id in np.unique(class_ids):
            mask = class_ids == class_id
            picked = nms(boxes[mask], scores[mask], self._iou)
            sub_boxes, sub_scores = boxes[mask], scores[mask]
            for index in picked:
                results.append(
                    Detection(
                        label=self._label_of(int(class_id)),
                        score=float(sub_scores[index]),
                        box=tuple(float(v) for v in sub_boxes[index]),  # type: ignore[arg-type]
                    )
                )
        results.sort(key=lambda d: d.score, reverse=True)
        return results

    def _label_of(self, class_id: int) -> str:
        if 0 <= class_id < len(self._labels):
            return self._labels[class_id]
        return f"class_{class_id}"


def _make_onnx_session(path: Path, preferred: Sequence[str]) -> Any:
    """실제 onnxruntime 세션을 만든다. 파일이 없으면 획득 절차를 담아 `ModelMissingError`."""
    if not path.is_file():
        raise ModelMissingError(
            f"모델 파일 없음: {path}\n"
            f"가중치는 저장소에 없다(용량·라이선스). `models/README.md` 의 획득 절차를 따른다."
        )
    import onnxruntime as ort

    available = list(ort.get_available_providers())
    chosen = select_providers(preferred, available)
    log_selection(chosen, available, preferred)
    return ort.InferenceSession(str(path), providers=chosen)
